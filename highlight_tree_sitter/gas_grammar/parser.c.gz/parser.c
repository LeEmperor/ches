#include "tree_sitter/parser.h"

#if defined(__GNUC__) || defined(__clang__)
#pragma GCC diagnostic ignored "-Wmissing-field-initializers"
#endif

#define LANGUAGE_VERSION 14
#define STATE_COUNT 142
#define LARGE_STATE_COUNT 2
#define SYMBOL_COUNT 70
#define ALIAS_COUNT 1
#define TOKEN_COUNT 43
#define EXTERNAL_TOKEN_COUNT 0
#define FIELD_COUNT 0
#define MAX_ALIAS_SEQUENCE_LENGTH 10
#define PRODUCTION_ID_COUNT 3

enum ts_symbol_identifiers {
  sym_label = 1,
  sym_local_label_reference = 2,
  anon_sym_COMMA = 3,
  anon_sym_DOTfile = 4,
  anon_sym_DOTloc = 5,
  sym_directive_name = 6,
  anon_sym_AT = 7,
  anon_sym_EQ = 8,
  anon_sym_DASH = 9,
  anon_sym_PLUS = 10,
  anon_sym_STAR = 11,
  anon_sym_SLASH = 12,
  anon_sym_LPAREN = 13,
  anon_sym_RPAREN = 14,
  aux_sym_instruction_prefix_token1 = 15,
  aux_sym_instruction_prefix_token2 = 16,
  aux_sym_instruction_prefix_token3 = 17,
  aux_sym_instruction_prefix_token4 = 18,
  aux_sym_instruction_prefix_token5 = 19,
  aux_sym_instruction_prefix_token6 = 20,
  aux_sym_instruction_prefix_token7 = 21,
  aux_sym_instruction_prefix_token8 = 22,
  aux_sym_instruction_prefix_token9 = 23,
  aux_sym_instruction_prefix_token10 = 24,
  aux_sym__operand_symbol_token1 = 25,
  sym_operand_modifier = 26,
  anon_sym_COLON = 27,
  anon_sym_DOLLAR = 28,
  anon_sym_SQUOTE = 29,
  aux_sym_char_token1 = 30,
  sym__character_escapes = 31,
  sym_string = 32,
  sym__integer = 33,
  sym__float = 34,
  sym__identifier = 35,
  sym_register = 36,
  aux_sym_comment_token1 = 37,
  anon_sym_SLASH_STAR = 38,
  aux_sym_comment_token2 = 39,
  anon_sym_STAR_SLASH = 40,
  sym__inline_space = 41,
  sym__eol = 42,
  sym_source_file = 43,
  sym__statement = 44,
  sym_directive = 45,
  sym__directive_arg = 46,
  sym_type = 47,
  sym_assignment = 48,
  sym_expression = 49,
  sym__paren_expression = 50,
  sym__sub_expression = 51,
  sym_instruction = 52,
  sym_instruction_prefix = 53,
  sym__operand = 54,
  sym__operand_symbol = 55,
  sym__displacement_expression = 56,
  sym__operand_expression = 57,
  sym__displacement_expression_offset = 58,
  sym_constant = 59,
  sym_char = 60,
  sym_number = 61,
  sym_symbol = 62,
  sym_comment = 63,
  aux_sym_source_file_repeat1 = 64,
  aux_sym_directive_repeat1 = 65,
  aux_sym_directive_repeat2 = 66,
  aux_sym_assignment_repeat1 = 67,
  aux_sym_instruction_repeat1 = 68,
  aux_sym_comment_repeat1 = 69,
  alias_sym_instruction_name = 70,
};

static const char * const ts_symbol_names[] = {
  [ts_builtin_sym_end] = "end",
  [sym_label] = "label",
  [sym_local_label_reference] = "local_label_reference",
  [anon_sym_COMMA] = ",",
  [anon_sym_DOTfile] = "directive_name",
  [anon_sym_DOTloc] = "directive_name",
  [sym_directive_name] = "directive_name",
  [anon_sym_AT] = "@",
  [anon_sym_EQ] = "=",
  [anon_sym_DASH] = "-",
  [anon_sym_PLUS] = "+",
  [anon_sym_STAR] = "*",
  [anon_sym_SLASH] = "/",
  [anon_sym_LPAREN] = "(",
  [anon_sym_RPAREN] = ")",
  [aux_sym_instruction_prefix_token1] = "instruction_prefix_token1",
  [aux_sym_instruction_prefix_token2] = "instruction_prefix_token2",
  [aux_sym_instruction_prefix_token3] = "instruction_prefix_token3",
  [aux_sym_instruction_prefix_token4] = "instruction_prefix_token4",
  [aux_sym_instruction_prefix_token5] = "instruction_prefix_token5",
  [aux_sym_instruction_prefix_token6] = "instruction_prefix_token6",
  [aux_sym_instruction_prefix_token7] = "instruction_prefix_token7",
  [aux_sym_instruction_prefix_token8] = "instruction_prefix_token8",
  [aux_sym_instruction_prefix_token9] = "instruction_prefix_token9",
  [aux_sym_instruction_prefix_token10] = "instruction_prefix_token10",
  [aux_sym__operand_symbol_token1] = "symbol",
  [sym_operand_modifier] = "operand_modifier",
  [anon_sym_COLON] = ":",
  [anon_sym_DOLLAR] = "$",
  [anon_sym_SQUOTE] = "'",
  [aux_sym_char_token1] = "char_token1",
  [sym__character_escapes] = "_character_escapes",
  [sym_string] = "string",
  [sym__integer] = "_integer",
  [sym__float] = "_float",
  [sym__identifier] = "_identifier",
  [sym_register] = "register",
  [aux_sym_comment_token1] = "comment_token1",
  [anon_sym_SLASH_STAR] = "/*",
  [aux_sym_comment_token2] = "comment_token2",
  [anon_sym_STAR_SLASH] = "*/",
  [sym__inline_space] = "_inline_space",
  [sym__eol] = "_eol",
  [sym_source_file] = "source_file",
  [sym__statement] = "_statement",
  [sym_directive] = "directive",
  [sym__directive_arg] = "_directive_arg",
  [sym_type] = "type",
  [sym_assignment] = "assignment",
  [sym_expression] = "expression",
  [sym__paren_expression] = "_paren_expression",
  [sym__sub_expression] = "_sub_expression",
  [sym_instruction] = "instruction",
  [sym_instruction_prefix] = "instruction_prefix",
  [sym__operand] = "_operand",
  [sym__operand_symbol] = "_operand_symbol",
  [sym__displacement_expression] = "_displacement_expression",
  [sym__operand_expression] = "_operand_expression",
  [sym__displacement_expression_offset] = "_displacement_expression_offset",
  [sym_constant] = "constant",
  [sym_char] = "char",
  [sym_number] = "number",
  [sym_symbol] = "symbol",
  [sym_comment] = "comment",
  [aux_sym_source_file_repeat1] = "source_file_repeat1",
  [aux_sym_directive_repeat1] = "directive_repeat1",
  [aux_sym_directive_repeat2] = "directive_repeat2",
  [aux_sym_assignment_repeat1] = "assignment_repeat1",
  [aux_sym_instruction_repeat1] = "instruction_repeat1",
  [aux_sym_comment_repeat1] = "comment_repeat1",
  [alias_sym_instruction_name] = "instruction_name",
};

static const TSSymbol ts_symbol_map[] = {
  [ts_builtin_sym_end] = ts_builtin_sym_end,
  [sym_label] = sym_label,
  [sym_local_label_reference] = sym_local_label_reference,
  [anon_sym_COMMA] = anon_sym_COMMA,
  [anon_sym_DOTfile] = sym_directive_name,
  [anon_sym_DOTloc] = sym_directive_name,
  [sym_directive_name] = sym_directive_name,
  [anon_sym_AT] = anon_sym_AT,
  [anon_sym_EQ] = anon_sym_EQ,
  [anon_sym_DASH] = anon_sym_DASH,
  [anon_sym_PLUS] = anon_sym_PLUS,
  [anon_sym_STAR] = anon_sym_STAR,
  [anon_sym_SLASH] = anon_sym_SLASH,
  [anon_sym_LPAREN] = anon_sym_LPAREN,
  [anon_sym_RPAREN] = anon_sym_RPAREN,
  [aux_sym_instruction_prefix_token1] = aux_sym_instruction_prefix_token1,
  [aux_sym_instruction_prefix_token2] = aux_sym_instruction_prefix_token2,
  [aux_sym_instruction_prefix_token3] = aux_sym_instruction_prefix_token3,
  [aux_sym_instruction_prefix_token4] = aux_sym_instruction_prefix_token4,
  [aux_sym_instruction_prefix_token5] = aux_sym_instruction_prefix_token5,
  [aux_sym_instruction_prefix_token6] = aux_sym_instruction_prefix_token6,
  [aux_sym_instruction_prefix_token7] = aux_sym_instruction_prefix_token7,
  [aux_sym_instruction_prefix_token8] = aux_sym_instruction_prefix_token8,
  [aux_sym_instruction_prefix_token9] = aux_sym_instruction_prefix_token9,
  [aux_sym_instruction_prefix_token10] = aux_sym_instruction_prefix_token10,
  [aux_sym__operand_symbol_token1] = sym_symbol,
  [sym_operand_modifier] = sym_operand_modifier,
  [anon_sym_COLON] = anon_sym_COLON,
  [anon_sym_DOLLAR] = anon_sym_DOLLAR,
  [anon_sym_SQUOTE] = anon_sym_SQUOTE,
  [aux_sym_char_token1] = aux_sym_char_token1,
  [sym__character_escapes] = sym__character_escapes,
  [sym_string] = sym_string,
  [sym__integer] = sym__integer,
  [sym__float] = sym__float,
  [sym__identifier] = sym__identifier,
  [sym_register] = sym_register,
  [aux_sym_comment_token1] = aux_sym_comment_token1,
  [anon_sym_SLASH_STAR] = anon_sym_SLASH_STAR,
  [aux_sym_comment_token2] = aux_sym_comment_token2,
  [anon_sym_STAR_SLASH] = anon_sym_STAR_SLASH,
  [sym__inline_space] = sym__inline_space,
  [sym__eol] = sym__eol,
  [sym_source_file] = sym_source_file,
  [sym__statement] = sym__statement,
  [sym_directive] = sym_directive,
  [sym__directive_arg] = sym__directive_arg,
  [sym_type] = sym_type,
  [sym_assignment] = sym_assignment,
  [sym_expression] = sym_expression,
  [sym__paren_expression] = sym__paren_expression,
  [sym__sub_expression] = sym__sub_expression,
  [sym_instruction] = sym_instruction,
  [sym_instruction_prefix] = sym_instruction_prefix,
  [sym__operand] = sym__operand,
  [sym__operand_symbol] = sym__operand_symbol,
  [sym__displacement_expression] = sym__displacement_expression,
  [sym__operand_expression] = sym__operand_expression,
  [sym__displacement_expression_offset] = sym__displacement_expression_offset,
  [sym_constant] = sym_constant,
  [sym_char] = sym_char,
  [sym_number] = sym_number,
  [sym_symbol] = sym_symbol,
  [sym_comment] = sym_comment,
  [aux_sym_source_file_repeat1] = aux_sym_source_file_repeat1,
  [aux_sym_directive_repeat1] = aux_sym_directive_repeat1,
  [aux_sym_directive_repeat2] = aux_sym_directive_repeat2,
  [aux_sym_assignment_repeat1] = aux_sym_assignment_repeat1,
  [aux_sym_instruction_repeat1] = aux_sym_instruction_repeat1,
  [aux_sym_comment_repeat1] = aux_sym_comment_repeat1,
  [alias_sym_instruction_name] = alias_sym_instruction_name,
};

static const TSSymbolMetadata ts_symbol_metadata[] = {
  [ts_builtin_sym_end] = {
    .visible = false,
    .named = true,
  },
  [sym_label] = {
    .visible = true,
    .named = true,
  },
  [sym_local_label_reference] = {
    .visible = true,
    .named = true,
  },
  [anon_sym_COMMA] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_DOTfile] = {
    .visible = true,
    .named = true,
  },
  [anon_sym_DOTloc] = {
    .visible = true,
    .named = true,
  },
  [sym_directive_name] = {
    .visible = true,
    .named = true,
  },
  [anon_sym_AT] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_EQ] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_DASH] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_PLUS] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_STAR] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_SLASH] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_LPAREN] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_RPAREN] = {
    .visible = true,
    .named = false,
  },
  [aux_sym_instruction_prefix_token1] = {
    .visible = false,
    .named = false,
  },
  [aux_sym_instruction_prefix_token2] = {
    .visible = false,
    .named = false,
  },
  [aux_sym_instruction_prefix_token3] = {
    .visible = false,
    .named = false,
  },
  [aux_sym_instruction_prefix_token4] = {
    .visible = false,
    .named = false,
  },
  [aux_sym_instruction_prefix_token5] = {
    .visible = false,
    .named = false,
  },
  [aux_sym_instruction_prefix_token6] = {
    .visible = false,
    .named = false,
  },
  [aux_sym_instruction_prefix_token7] = {
    .visible = false,
    .named = false,
  },
  [aux_sym_instruction_prefix_token8] = {
    .visible = false,
    .named = false,
  },
  [aux_sym_instruction_prefix_token9] = {
    .visible = false,
    .named = false,
  },
  [aux_sym_instruction_prefix_token10] = {
    .visible = false,
    .named = false,
  },
  [aux_sym__operand_symbol_token1] = {
    .visible = true,
    .named = true,
  },
  [sym_operand_modifier] = {
    .visible = true,
    .named = true,
  },
  [anon_sym_COLON] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_DOLLAR] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_SQUOTE] = {
    .visible = true,
    .named = false,
  },
  [aux_sym_char_token1] = {
    .visible = false,
    .named = false,
  },
  [sym__character_escapes] = {
    .visible = false,
    .named = true,
  },
  [sym_string] = {
    .visible = true,
    .named = true,
  },
  [sym__integer] = {
    .visible = false,
    .named = true,
  },
  [sym__float] = {
    .visible = false,
    .named = true,
  },
  [sym__identifier] = {
    .visible = false,
    .named = true,
  },
  [sym_register] = {
    .visible = true,
    .named = true,
  },
  [aux_sym_comment_token1] = {
    .visible = false,
    .named = false,
  },
  [anon_sym_SLASH_STAR] = {
    .visible = true,
    .named = false,
  },
  [aux_sym_comment_token2] = {
    .visible = false,
    .named = false,
  },
  [anon_sym_STAR_SLASH] = {
    .visible = true,
    .named = false,
  },
  [sym__inline_space] = {
    .visible = false,
    .named = true,
  },
  [sym__eol] = {
    .visible = false,
    .named = true,
  },
  [sym_source_file] = {
    .visible = true,
    .named = true,
  },
  [sym__statement] = {
    .visible = false,
    .named = true,
  },
  [sym_directive] = {
    .visible = true,
    .named = true,
  },
  [sym__directive_arg] = {
    .visible = false,
    .named = true,
  },
  [sym_type] = {
    .visible = true,
    .named = true,
  },
  [sym_assignment] = {
    .visible = true,
    .named = true,
  },
  [sym_expression] = {
    .visible = true,
    .named = true,
  },
  [sym__paren_expression] = {
    .visible = false,
    .named = true,
  },
  [sym__sub_expression] = {
    .visible = false,
    .named = true,
  },
  [sym_instruction] = {
    .visible = true,
    .named = true,
  },
  [sym_instruction_prefix] = {
    .visible = true,
    .named = true,
  },
  [sym__operand] = {
    .visible = false,
    .named = true,
  },
  [sym__operand_symbol] = {
    .visible = false,
    .named = true,
  },
  [sym__displacement_expression] = {
    .visible = false,
    .named = true,
  },
  [sym__operand_expression] = {
    .visible = false,
    .named = true,
  },
  [sym__displacement_expression_offset] = {
    .visible = false,
    .named = true,
  },
  [sym_constant] = {
    .visible = true,
    .named = true,
  },
  [sym_char] = {
    .visible = true,
    .named = true,
  },
  [sym_number] = {
    .visible = true,
    .named = true,
  },
  [sym_symbol] = {
    .visible = true,
    .named = true,
  },
  [sym_comment] = {
    .visible = true,
    .named = true,
  },
  [aux_sym_source_file_repeat1] = {
    .visible = false,
    .named = false,
  },
  [aux_sym_directive_repeat1] = {
    .visible = false,
    .named = false,
  },
  [aux_sym_directive_repeat2] = {
    .visible = false,
    .named = false,
  },
  [aux_sym_assignment_repeat1] = {
    .visible = false,
    .named = false,
  },
  [aux_sym_instruction_repeat1] = {
    .visible = false,
    .named = false,
  },
  [aux_sym_comment_repeat1] = {
    .visible = false,
    .named = false,
  },
  [alias_sym_instruction_name] = {
    .visible = true,
    .named = true,
  },
};

static const TSSymbol ts_alias_sequences[PRODUCTION_ID_COUNT][MAX_ALIAS_SEQUENCE_LENGTH] = {
  [0] = {0},
  [1] = {
    [0] = alias_sym_instruction_name,
  },
  [2] = {
    [2] = alias_sym_instruction_name,
  },
};

static const uint16_t ts_non_terminal_alias_map[] = {
  sym_symbol, 2,
    sym_symbol,
    alias_sym_instruction_name,
  0,
};

static const TSStateId ts_primary_state_ids[STATE_COUNT] = {
  [0] = 0,
  [1] = 1,
  [2] = 2,
  [3] = 3,
  [4] = 4,
  [5] = 5,
  [6] = 6,
  [7] = 7,
  [8] = 8,
  [9] = 9,
  [10] = 10,
  [11] = 11,
  [12] = 12,
  [13] = 13,
  [14] = 14,
  [15] = 15,
  [16] = 16,
  [17] = 17,
  [18] = 18,
  [19] = 19,
  [20] = 20,
  [21] = 21,
  [22] = 22,
  [23] = 23,
  [24] = 24,
  [25] = 25,
  [26] = 26,
  [27] = 27,
  [28] = 28,
  [29] = 29,
  [30] = 30,
  [31] = 31,
  [32] = 32,
  [33] = 33,
  [34] = 34,
  [35] = 35,
  [36] = 36,
  [37] = 37,
  [38] = 38,
  [39] = 39,
  [40] = 40,
  [41] = 41,
  [42] = 42,
  [43] = 43,
  [44] = 44,
  [45] = 45,
  [46] = 46,
  [47] = 47,
  [48] = 48,
  [49] = 49,
  [50] = 50,
  [51] = 51,
  [52] = 52,
  [53] = 53,
  [54] = 54,
  [55] = 55,
  [56] = 55,
  [57] = 57,
  [58] = 58,
  [59] = 59,
  [60] = 59,
  [61] = 61,
  [62] = 62,
  [63] = 63,
  [64] = 64,
  [65] = 65,
  [66] = 66,
  [67] = 67,
  [68] = 68,
  [69] = 69,
  [70] = 70,
  [71] = 71,
  [72] = 72,
  [73] = 73,
  [74] = 74,
  [75] = 75,
  [76] = 76,
  [77] = 77,
  [78] = 78,
  [79] = 79,
  [80] = 38,
  [81] = 81,
  [82] = 82,
  [83] = 83,
  [84] = 84,
  [85] = 85,
  [86] = 86,
  [87] = 87,
  [88] = 88,
  [89] = 89,
  [90] = 90,
  [91] = 91,
  [92] = 92,
  [93] = 93,
  [94] = 94,
  [95] = 20,
  [96] = 96,
  [97] = 97,
  [98] = 98,
  [99] = 99,
  [100] = 100,
  [101] = 101,
  [102] = 102,
  [103] = 103,
  [104] = 104,
  [105] = 105,
  [106] = 106,
  [107] = 107,
  [108] = 38,
  [109] = 109,
  [110] = 110,
  [111] = 111,
  [112] = 112,
  [113] = 113,
  [114] = 114,
  [115] = 115,
  [116] = 116,
  [117] = 117,
  [118] = 118,
  [119] = 119,
  [120] = 120,
  [121] = 121,
  [122] = 122,
  [123] = 123,
  [124] = 124,
  [125] = 125,
  [126] = 126,
  [127] = 127,
  [128] = 128,
  [129] = 129,
  [130] = 130,
  [131] = 131,
  [132] = 132,
  [133] = 133,
  [134] = 134,
  [135] = 135,
  [136] = 136,
  [137] = 137,
  [138] = 138,
  [139] = 133,
  [140] = 130,
  [141] = 132,
};

static bool ts_lex(TSLexer *lexer, TSStateId state) {
  START_LEXER();
  eof = lexer->eof(lexer);
  switch (state) {
    case 0:
      if (eof) ADVANCE(23);
      ADVANCE_MAP(
        '\n', 65,
        '#', 68,
        '$', 63,
        '\'', 64,
        '(', 44,
        ')', 45,
        '*', 42,
        '+', 40,
        ',', 28,
        '-', 39,
        '/', 43,
        ':', 62,
        '=', 38,
        '@', 37,
        '\\', 118,
        '\t', 67,
        ' ', 67,
      );
      if (lookahead == '.' ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(60);
      if (lookahead != 0) ADVANCE(65);
      END_STATE();
    case 1:
      ADVANCE_MAP(
        '\n', 127,
        '\r', 119,
        '#', 116,
        '*', 121,
        '/', 120,
        ';', 118,
        '\t', 122,
        ' ', 122,
      );
      if (lookahead != 0) ADVANCE(118);
      END_STATE();
    case 2:
      ADVANCE_MAP(
        '"', 3,
        '#', 116,
        '$', 63,
        '%', 18,
        '\'', 64,
        '(', 44,
        '*', 41,
        '-', 6,
        '/', 5,
        '0', 74,
        '=', 38,
        '\t', 124,
        ' ', 124,
      );
      if (('1' <= lookahead && lookahead <= '9')) ADVANCE(79);
      if (lookahead == '.' ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(60);
      END_STATE();
    case 3:
      if (lookahead == '"') ADVANCE(70);
      if (lookahead == '\\') ADVANCE(8);
      if (lookahead != 0 &&
          lookahead != '\n' &&
          lookahead != '\r') ADVANCE(3);
      END_STATE();
    case 4:
      if (lookahead == '#') ADVANCE(68);
      if (lookahead == '/') ADVANCE(66);
      if (lookahead == '\\') ADVANCE(11);
      if (lookahead == '\t' ||
          lookahead == ' ') ADVANCE(67);
      if (lookahead != 0 &&
          lookahead != '\'') ADVANCE(65);
      END_STATE();
    case 5:
      if (lookahead == '*') ADVANCE(117);
      END_STATE();
    case 6:
      if (lookahead == '0') ADVANCE(77);
      if (('1' <= lookahead && lookahead <= '9')) ADVANCE(82);
      END_STATE();
    case 7:
      if (lookahead == ':') ADVANCE(24);
      if (('0' <= lookahead && lookahead <= '9')) ADVANCE(7);
      END_STATE();
    case 8:
      ADVANCE_MAP(
        'x', 17,
        '"', 3,
        '\\', 3,
        'b', 3,
        'f', 3,
        'n', 3,
        'r', 3,
        't', 3,
      );
      if (('0' <= lookahead && lookahead <= '9')) ADVANCE(14);
      END_STATE();
    case 9:
      if (lookahead == '+' ||
          lookahead == '-') ADVANCE(13);
      if (('0' <= lookahead && lookahead <= '9')) ADVANCE(89);
      END_STATE();
    case 10:
      if (lookahead == 'b' ||
          lookahead == 'f') ADVANCE(25);
      if (('0' <= lookahead && lookahead <= '9')) ADVANCE(10);
      END_STATE();
    case 11:
      ADVANCE_MAP(
        '"', 69,
        '\'', 69,
        '\\', 69,
        'b', 69,
        'f', 69,
        'n', 69,
        'r', 69,
        't', 69,
      );
      END_STATE();
    case 12:
      if (('0' <= lookahead && lookahead <= '9')) ADVANCE(3);
      END_STATE();
    case 13:
      if (('0' <= lookahead && lookahead <= '9')) ADVANCE(89);
      END_STATE();
    case 14:
      if (('0' <= lookahead && lookahead <= '9')) ADVANCE(12);
      END_STATE();
    case 15:
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'F') ||
          ('a' <= lookahead && lookahead <= 'f')) ADVANCE(3);
      END_STATE();
    case 16:
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'F') ||
          ('a' <= lookahead && lookahead <= 'f')) ADVANCE(84);
      END_STATE();
    case 17:
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'F') ||
          ('a' <= lookahead && lookahead <= 'f')) ADVANCE(15);
      END_STATE();
    case 18:
      if (('A' <= lookahead && lookahead <= 'Z') ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(115);
      END_STATE();
    case 19:
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(61);
      END_STATE();
    case 20:
      if (eof) ADVANCE(23);
      ADVANCE_MAP(
        '\n', 127,
        '\r', 126,
        '"', 3,
        '#', 116,
        '\'', 64,
        '(', 44,
        ',', 28,
        '-', 6,
        '/', 5,
        '0', 74,
        ';', 125,
        '@', 37,
        '\t', 124,
        ' ', 124,
      );
      if (('1' <= lookahead && lookahead <= '9')) ADVANCE(79);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(114);
      END_STATE();
    case 21:
      if (eof) ADVANCE(23);
      ADVANCE_MAP(
        '\n', 127,
        '\r', 126,
        '"', 3,
        '#', 116,
        '-', 6,
        '/', 5,
        '0', 76,
        ';', 125,
        '\t', 124,
        ' ', 124,
      );
      if (('1' <= lookahead && lookahead <= '9')) ADVANCE(82);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(114);
      END_STATE();
    case 22:
      if (eof) ADVANCE(23);
      ADVANCE_MAP(
        '\n', 127,
        '\r', 126,
        '#', 116,
        '%', 18,
        '\'', 64,
        '(', 44,
        ')', 45,
        '*', 41,
        '+', 40,
        ',', 28,
        '-', 39,
        '.', 97,
        '/', 43,
        ':', 62,
        ';', 125,
        '=', 38,
        '@', 19,
        '\t', 124,
        ' ', 124,
        'A', 103,
        'a', 103,
        'D', 98,
        'd', 98,
        'L', 108,
        'l', 108,
        'R', 104,
        'r', 104,
        'W', 99,
        'w', 99,
      );
      if (('0' <= lookahead && lookahead <= '9')) ADVANCE(7);
      if (lookahead == '$' ||
          ('B' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('b' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 23:
      ACCEPT_TOKEN(ts_builtin_sym_end);
      END_STATE();
    case 24:
      ACCEPT_TOKEN(sym_label);
      END_STATE();
    case 25:
      ACCEPT_TOKEN(sym_local_label_reference);
      END_STATE();
    case 26:
      ACCEPT_TOKEN(sym_local_label_reference);
      if (lookahead == '.') ADVANCE(88);
      if (lookahead == '+' ||
          lookahead == '-') ADVANCE(87);
      if (lookahead == 'E' ||
          lookahead == 'e') ADVANCE(9);
      if (lookahead == '0' ||
          lookahead == '1') ADVANCE(72);
      if (('2' <= lookahead && lookahead <= '9')) ADVANCE(87);
      END_STATE();
    case 27:
      ACCEPT_TOKEN(sym_local_label_reference);
      if (lookahead == '.') ADVANCE(88);
      if (lookahead == '+' ||
          lookahead == '-') ADVANCE(87);
      if (lookahead == 'E' ||
          lookahead == 'e') ADVANCE(9);
      if (('0' <= lookahead && lookahead <= '9')) ADVANCE(87);
      END_STATE();
    case 28:
      ACCEPT_TOKEN(anon_sym_COMMA);
      END_STATE();
    case 29:
      ACCEPT_TOKEN(anon_sym_DOTfile);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(36);
      END_STATE();
    case 30:
      ACCEPT_TOKEN(anon_sym_DOTloc);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(36);
      END_STATE();
    case 31:
      ACCEPT_TOKEN(sym_directive_name);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == 'c') ADVANCE(30);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(36);
      END_STATE();
    case 32:
      ACCEPT_TOKEN(sym_directive_name);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == 'e') ADVANCE(29);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(36);
      END_STATE();
    case 33:
      ACCEPT_TOKEN(sym_directive_name);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == 'i') ADVANCE(34);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(36);
      END_STATE();
    case 34:
      ACCEPT_TOKEN(sym_directive_name);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == 'l') ADVANCE(32);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(36);
      END_STATE();
    case 35:
      ACCEPT_TOKEN(sym_directive_name);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == 'o') ADVANCE(31);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(36);
      END_STATE();
    case 36:
      ACCEPT_TOKEN(sym_directive_name);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(36);
      END_STATE();
    case 37:
      ACCEPT_TOKEN(anon_sym_AT);
      END_STATE();
    case 38:
      ACCEPT_TOKEN(anon_sym_EQ);
      END_STATE();
    case 39:
      ACCEPT_TOKEN(anon_sym_DASH);
      END_STATE();
    case 40:
      ACCEPT_TOKEN(anon_sym_PLUS);
      END_STATE();
    case 41:
      ACCEPT_TOKEN(anon_sym_STAR);
      END_STATE();
    case 42:
      ACCEPT_TOKEN(anon_sym_STAR);
      if (lookahead == '/') ADVANCE(123);
      END_STATE();
    case 43:
      ACCEPT_TOKEN(anon_sym_SLASH);
      if (lookahead == '*') ADVANCE(117);
      END_STATE();
    case 44:
      ACCEPT_TOKEN(anon_sym_LPAREN);
      END_STATE();
    case 45:
      ACCEPT_TOKEN(anon_sym_RPAREN);
      END_STATE();
    case 46:
      ACCEPT_TOKEN(aux_sym_instruction_prefix_token1);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 47:
      ACCEPT_TOKEN(aux_sym_instruction_prefix_token2);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 48:
      ACCEPT_TOKEN(aux_sym_instruction_prefix_token3);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 49:
      ACCEPT_TOKEN(aux_sym_instruction_prefix_token4);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 50:
      ACCEPT_TOKEN(aux_sym_instruction_prefix_token5);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 51:
      ACCEPT_TOKEN(aux_sym_instruction_prefix_token6);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 52:
      ACCEPT_TOKEN(aux_sym_instruction_prefix_token7);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == 'E' ||
          lookahead == 'e') ADVANCE(53);
      if (lookahead == 'N' ||
          lookahead == 'n') ADVANCE(105);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 53:
      ACCEPT_TOKEN(aux_sym_instruction_prefix_token8);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 54:
      ACCEPT_TOKEN(aux_sym_instruction_prefix_token9);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 55:
      ACCEPT_TOKEN(aux_sym_instruction_prefix_token10);
      ADVANCE_MAP(
        '6', 94,
        ':', 24,
        'X', 57,
        'x', 57,
        'Y', 58,
        'y', 58,
        'Z', 59,
        'z', 59,
      );
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'W') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'w')) ADVANCE(113);
      END_STATE();
    case 56:
      ACCEPT_TOKEN(aux_sym_instruction_prefix_token10);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == 'X' ||
          lookahead == 'x') ADVANCE(57);
      if (lookahead == 'Y' ||
          lookahead == 'y') ADVANCE(58);
      if (lookahead == 'Z' ||
          lookahead == 'z') ADVANCE(59);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'W') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'w')) ADVANCE(113);
      END_STATE();
    case 57:
      ACCEPT_TOKEN(aux_sym_instruction_prefix_token10);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == 'Y' ||
          lookahead == 'y') ADVANCE(58);
      if (lookahead == 'Z' ||
          lookahead == 'z') ADVANCE(59);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'X') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'x')) ADVANCE(113);
      END_STATE();
    case 58:
      ACCEPT_TOKEN(aux_sym_instruction_prefix_token10);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == 'Z' ||
          lookahead == 'z') ADVANCE(59);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Y') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'y')) ADVANCE(113);
      END_STATE();
    case 59:
      ACCEPT_TOKEN(aux_sym_instruction_prefix_token10);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 60:
      ACCEPT_TOKEN(aux_sym__operand_symbol_token1);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(60);
      END_STATE();
    case 61:
      ACCEPT_TOKEN(sym_operand_modifier);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(61);
      END_STATE();
    case 62:
      ACCEPT_TOKEN(anon_sym_COLON);
      END_STATE();
    case 63:
      ACCEPT_TOKEN(anon_sym_DOLLAR);
      END_STATE();
    case 64:
      ACCEPT_TOKEN(anon_sym_SQUOTE);
      END_STATE();
    case 65:
      ACCEPT_TOKEN(aux_sym_char_token1);
      END_STATE();
    case 66:
      ACCEPT_TOKEN(aux_sym_char_token1);
      if (lookahead == '*') ADVANCE(117);
      END_STATE();
    case 67:
      ACCEPT_TOKEN(aux_sym_char_token1);
      if (lookahead == '\t' ||
          lookahead == ' ') ADVANCE(124);
      END_STATE();
    case 68:
      ACCEPT_TOKEN(aux_sym_char_token1);
      if (lookahead != 0 &&
          lookahead != '\n') ADVANCE(116);
      END_STATE();
    case 69:
      ACCEPT_TOKEN(sym__character_escapes);
      END_STATE();
    case 70:
      ACCEPT_TOKEN(sym_string);
      END_STATE();
    case 71:
      ACCEPT_TOKEN(sym__integer);
      if (lookahead == '.') ADVANCE(88);
      if (lookahead == '+' ||
          lookahead == '-') ADVANCE(87);
      if (lookahead == 'E' ||
          lookahead == 'e') ADVANCE(9);
      if (lookahead == '0' ||
          lookahead == '1') ADVANCE(72);
      if (('2' <= lookahead && lookahead <= '9')) ADVANCE(87);
      END_STATE();
    case 72:
      ACCEPT_TOKEN(sym__integer);
      if (lookahead == '.') ADVANCE(88);
      if (lookahead == 'E' ||
          lookahead == 'e') ADVANCE(9);
      if (lookahead == '0' ||
          lookahead == '1') ADVANCE(72);
      if (('2' <= lookahead && lookahead <= '9')) ADVANCE(87);
      END_STATE();
    case 73:
      ACCEPT_TOKEN(sym__integer);
      if (lookahead == '.') ADVANCE(88);
      if (lookahead == 'E' ||
          lookahead == 'e') ADVANCE(75);
      if (('A' <= lookahead && lookahead <= 'F') ||
          ('a' <= lookahead && lookahead <= 'f')) ADVANCE(84);
      if (('0' <= lookahead && lookahead <= '9')) ADVANCE(73);
      END_STATE();
    case 74:
      ACCEPT_TOKEN(sym__integer);
      if (lookahead == 'B') ADVANCE(71);
      if (lookahead == 'b') ADVANCE(26);
      if (lookahead == 'f') ADVANCE(27);
      if (lookahead == 'X' ||
          lookahead == 'x') ADVANCE(86);
      if (lookahead == '8' ||
          lookahead == '9') ADVANCE(10);
      if (('0' <= lookahead && lookahead <= '7')) ADVANCE(78);
      if (('A' <= lookahead && lookahead <= 'Z') ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(85);
      END_STATE();
    case 75:
      ACCEPT_TOKEN(sym__integer);
      if (lookahead == '+' ||
          lookahead == '-') ADVANCE(13);
      if (('0' <= lookahead && lookahead <= '9')) ADVANCE(83);
      if (('A' <= lookahead && lookahead <= 'F') ||
          ('a' <= lookahead && lookahead <= 'f')) ADVANCE(84);
      END_STATE();
    case 76:
      ACCEPT_TOKEN(sym__integer);
      if (lookahead == 'B' ||
          lookahead == 'b') ADVANCE(71);
      if (lookahead == 'X' ||
          lookahead == 'x') ADVANCE(86);
      if (('0' <= lookahead && lookahead <= '7')) ADVANCE(81);
      if (('A' <= lookahead && lookahead <= 'Z') ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(85);
      END_STATE();
    case 77:
      ACCEPT_TOKEN(sym__integer);
      if (lookahead == 'B' ||
          lookahead == 'b') ADVANCE(80);
      if (lookahead == 'X' ||
          lookahead == 'x') ADVANCE(16);
      if (('0' <= lookahead && lookahead <= '7')) ADVANCE(81);
      END_STATE();
    case 78:
      ACCEPT_TOKEN(sym__integer);
      if (lookahead == 'b' ||
          lookahead == 'f') ADVANCE(25);
      if (lookahead == '8' ||
          lookahead == '9') ADVANCE(10);
      if (('0' <= lookahead && lookahead <= '7')) ADVANCE(78);
      END_STATE();
    case 79:
      ACCEPT_TOKEN(sym__integer);
      if (lookahead == 'b' ||
          lookahead == 'f') ADVANCE(25);
      if (('0' <= lookahead && lookahead <= '9')) ADVANCE(79);
      END_STATE();
    case 80:
      ACCEPT_TOKEN(sym__integer);
      if (lookahead == '0' ||
          lookahead == '1') ADVANCE(80);
      END_STATE();
    case 81:
      ACCEPT_TOKEN(sym__integer);
      if (('0' <= lookahead && lookahead <= '7')) ADVANCE(81);
      END_STATE();
    case 82:
      ACCEPT_TOKEN(sym__integer);
      if (('0' <= lookahead && lookahead <= '9')) ADVANCE(82);
      END_STATE();
    case 83:
      ACCEPT_TOKEN(sym__integer);
      if (('0' <= lookahead && lookahead <= '9')) ADVANCE(83);
      if (('A' <= lookahead && lookahead <= 'F') ||
          ('a' <= lookahead && lookahead <= 'f')) ADVANCE(84);
      END_STATE();
    case 84:
      ACCEPT_TOKEN(sym__integer);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'F') ||
          ('a' <= lookahead && lookahead <= 'f')) ADVANCE(84);
      END_STATE();
    case 85:
      ACCEPT_TOKEN(sym__float);
      if (lookahead == '.') ADVANCE(88);
      if (lookahead == '+' ||
          lookahead == '-') ADVANCE(87);
      if (lookahead == 'E' ||
          lookahead == 'e') ADVANCE(9);
      if (('0' <= lookahead && lookahead <= '9')) ADVANCE(87);
      END_STATE();
    case 86:
      ACCEPT_TOKEN(sym__float);
      if (lookahead == '.') ADVANCE(88);
      if (lookahead == '+' ||
          lookahead == '-') ADVANCE(87);
      if (lookahead == 'E' ||
          lookahead == 'e') ADVANCE(75);
      if (('A' <= lookahead && lookahead <= 'F') ||
          ('a' <= lookahead && lookahead <= 'f')) ADVANCE(84);
      if (('0' <= lookahead && lookahead <= '9')) ADVANCE(73);
      END_STATE();
    case 87:
      ACCEPT_TOKEN(sym__float);
      if (lookahead == '.') ADVANCE(88);
      if (lookahead == 'E' ||
          lookahead == 'e') ADVANCE(9);
      if (('0' <= lookahead && lookahead <= '9')) ADVANCE(87);
      END_STATE();
    case 88:
      ACCEPT_TOKEN(sym__float);
      if (lookahead == 'E' ||
          lookahead == 'e') ADVANCE(9);
      if (('0' <= lookahead && lookahead <= '9')) ADVANCE(88);
      END_STATE();
    case 89:
      ACCEPT_TOKEN(sym__float);
      if (('0' <= lookahead && lookahead <= '9')) ADVANCE(89);
      END_STATE();
    case 90:
      ACCEPT_TOKEN(sym__identifier);
      if (lookahead == '1') ADVANCE(95);
      if (lookahead == '3') ADVANCE(92);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 91:
      ACCEPT_TOKEN(sym__identifier);
      if (lookahead == '1') ADVANCE(96);
      if (lookahead == '3') ADVANCE(93);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 92:
      ACCEPT_TOKEN(sym__identifier);
      if (lookahead == '2') ADVANCE(49);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 93:
      ACCEPT_TOKEN(sym__identifier);
      if (lookahead == '2') ADVANCE(48);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 94:
      ACCEPT_TOKEN(sym__identifier);
      if (lookahead == '4') ADVANCE(56);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 95:
      ACCEPT_TOKEN(sym__identifier);
      if (lookahead == '6') ADVANCE(47);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 96:
      ACCEPT_TOKEN(sym__identifier);
      if (lookahead == '6') ADVANCE(46);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 97:
      ACCEPT_TOKEN(sym__identifier);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == 'f') ADVANCE(33);
      if (lookahead == 'l') ADVANCE(35);
      if (('0' <= lookahead && lookahead <= '9')) ADVANCE(113);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(36);
      END_STATE();
    case 98:
      ACCEPT_TOKEN(sym__identifier);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == 'A' ||
          lookahead == 'a') ADVANCE(112);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('B' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('b' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 99:
      ACCEPT_TOKEN(sym__identifier);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == 'A' ||
          lookahead == 'a') ADVANCE(106);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('B' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('b' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 100:
      ACCEPT_TOKEN(sym__identifier);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == 'A' ||
          lookahead == 'a') ADVANCE(91);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('B' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('b' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 101:
      ACCEPT_TOKEN(sym__identifier);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == 'C' ||
          lookahead == 'c') ADVANCE(107);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 102:
      ACCEPT_TOKEN(sym__identifier);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == 'D' ||
          lookahead == 'd') ADVANCE(110);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 103:
      ACCEPT_TOKEN(sym__identifier);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == 'D' ||
          lookahead == 'd') ADVANCE(102);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 104:
      ACCEPT_TOKEN(sym__identifier);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == 'E' ||
          lookahead == 'e') ADVANCE(109);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 105:
      ACCEPT_TOKEN(sym__identifier);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == 'E' ||
          lookahead == 'e') ADVANCE(54);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 106:
      ACCEPT_TOKEN(sym__identifier);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == 'I' ||
          lookahead == 'i') ADVANCE(111);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 107:
      ACCEPT_TOKEN(sym__identifier);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == 'K' ||
          lookahead == 'k') ADVANCE(50);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 108:
      ACCEPT_TOKEN(sym__identifier);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == 'O' ||
          lookahead == 'o') ADVANCE(101);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 109:
      ACCEPT_TOKEN(sym__identifier);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == 'P' ||
          lookahead == 'p') ADVANCE(52);
      if (lookahead == 'X' ||
          lookahead == 'x') ADVANCE(55);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 110:
      ACCEPT_TOKEN(sym__identifier);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == 'R' ||
          lookahead == 'r') ADVANCE(90);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 111:
      ACCEPT_TOKEN(sym__identifier);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == 'T' ||
          lookahead == 't') ADVANCE(51);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 112:
      ACCEPT_TOKEN(sym__identifier);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == 'T' ||
          lookahead == 't') ADVANCE(100);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 113:
      ACCEPT_TOKEN(sym__identifier);
      if (lookahead == ':') ADVANCE(24);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(113);
      END_STATE();
    case 114:
      ACCEPT_TOKEN(sym__identifier);
      if (lookahead == '$' ||
          lookahead == '.' ||
          ('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(114);
      END_STATE();
    case 115:
      ACCEPT_TOKEN(sym_register);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(115);
      END_STATE();
    case 116:
      ACCEPT_TOKEN(aux_sym_comment_token1);
      if (lookahead != 0 &&
          lookahead != '\n') ADVANCE(116);
      END_STATE();
    case 117:
      ACCEPT_TOKEN(anon_sym_SLASH_STAR);
      END_STATE();
    case 118:
      ACCEPT_TOKEN(aux_sym_comment_token2);
      END_STATE();
    case 119:
      ACCEPT_TOKEN(aux_sym_comment_token2);
      if (lookahead == '\n') ADVANCE(125);
      END_STATE();
    case 120:
      ACCEPT_TOKEN(aux_sym_comment_token2);
      if (lookahead == '*') ADVANCE(117);
      END_STATE();
    case 121:
      ACCEPT_TOKEN(aux_sym_comment_token2);
      if (lookahead == '/') ADVANCE(123);
      END_STATE();
    case 122:
      ACCEPT_TOKEN(aux_sym_comment_token2);
      if (lookahead == '\t' ||
          lookahead == ' ') ADVANCE(124);
      END_STATE();
    case 123:
      ACCEPT_TOKEN(anon_sym_STAR_SLASH);
      END_STATE();
    case 124:
      ACCEPT_TOKEN(sym__inline_space);
      if (lookahead == '\t' ||
          lookahead == ' ') ADVANCE(124);
      END_STATE();
    case 125:
      ACCEPT_TOKEN(sym__eol);
      END_STATE();
    case 126:
      ACCEPT_TOKEN(sym__eol);
      if (lookahead == '\n') ADVANCE(125);
      END_STATE();
    case 127:
      ACCEPT_TOKEN(sym__eol);
      if (lookahead == '\r') ADVANCE(125);
      END_STATE();
    default:
      return false;
  }
}

static const TSLexMode ts_lex_modes[STATE_COUNT] = {
  [0] = {.lex_state = 0},
  [1] = {.lex_state = 22},
  [2] = {.lex_state = 22},
  [3] = {.lex_state = 22},
  [4] = {.lex_state = 22},
  [5] = {.lex_state = 22},
  [6] = {.lex_state = 22},
  [7] = {.lex_state = 20},
  [8] = {.lex_state = 2},
  [9] = {.lex_state = 2},
  [10] = {.lex_state = 2},
  [11] = {.lex_state = 22},
  [12] = {.lex_state = 22},
  [13] = {.lex_state = 2},
  [14] = {.lex_state = 22},
  [15] = {.lex_state = 2},
  [16] = {.lex_state = 20},
  [17] = {.lex_state = 20},
  [18] = {.lex_state = 20},
  [19] = {.lex_state = 20},
  [20] = {.lex_state = 22},
  [21] = {.lex_state = 20},
  [22] = {.lex_state = 22},
  [23] = {.lex_state = 20},
  [24] = {.lex_state = 2},
  [25] = {.lex_state = 22},
  [26] = {.lex_state = 22},
  [27] = {.lex_state = 2},
  [28] = {.lex_state = 22},
  [29] = {.lex_state = 2},
  [30] = {.lex_state = 22},
  [31] = {.lex_state = 22},
  [32] = {.lex_state = 2},
  [33] = {.lex_state = 2},
  [34] = {.lex_state = 2},
  [35] = {.lex_state = 22},
  [36] = {.lex_state = 22},
  [37] = {.lex_state = 22},
  [38] = {.lex_state = 22},
  [39] = {.lex_state = 2},
  [40] = {.lex_state = 22},
  [41] = {.lex_state = 2},
  [42] = {.lex_state = 21},
  [43] = {.lex_state = 22},
  [44] = {.lex_state = 2},
  [45] = {.lex_state = 2},
  [46] = {.lex_state = 22},
  [47] = {.lex_state = 21},
  [48] = {.lex_state = 2},
  [49] = {.lex_state = 22},
  [50] = {.lex_state = 22},
  [51] = {.lex_state = 2},
  [52] = {.lex_state = 21},
  [53] = {.lex_state = 22},
  [54] = {.lex_state = 22},
  [55] = {.lex_state = 1},
  [56] = {.lex_state = 1},
  [57] = {.lex_state = 22},
  [58] = {.lex_state = 22},
  [59] = {.lex_state = 1},
  [60] = {.lex_state = 1},
  [61] = {.lex_state = 22},
  [62] = {.lex_state = 22},
  [63] = {.lex_state = 22},
  [64] = {.lex_state = 22},
  [65] = {.lex_state = 22},
  [66] = {.lex_state = 22},
  [67] = {.lex_state = 22},
  [68] = {.lex_state = 22},
  [69] = {.lex_state = 22},
  [70] = {.lex_state = 22},
  [71] = {.lex_state = 22},
  [72] = {.lex_state = 22},
  [73] = {.lex_state = 22},
  [74] = {.lex_state = 1},
  [75] = {.lex_state = 22},
  [76] = {.lex_state = 22},
  [77] = {.lex_state = 22},
  [78] = {.lex_state = 22},
  [79] = {.lex_state = 22},
  [80] = {.lex_state = 22},
  [81] = {.lex_state = 22},
  [82] = {.lex_state = 22},
  [83] = {.lex_state = 1},
  [84] = {.lex_state = 22},
  [85] = {.lex_state = 22},
  [86] = {.lex_state = 22},
  [87] = {.lex_state = 22},
  [88] = {.lex_state = 22},
  [89] = {.lex_state = 22},
  [90] = {.lex_state = 22},
  [91] = {.lex_state = 22},
  [92] = {.lex_state = 22},
  [93] = {.lex_state = 22},
  [94] = {.lex_state = 22},
  [95] = {.lex_state = 22},
  [96] = {.lex_state = 22},
  [97] = {.lex_state = 22},
  [98] = {.lex_state = 22},
  [99] = {.lex_state = 4},
  [100] = {.lex_state = 22},
  [101] = {.lex_state = 22},
  [102] = {.lex_state = 22},
  [103] = {.lex_state = 20},
  [104] = {.lex_state = 22},
  [105] = {.lex_state = 22},
  [106] = {.lex_state = 22},
  [107] = {.lex_state = 22},
  [108] = {.lex_state = 22},
  [109] = {.lex_state = 22},
  [110] = {.lex_state = 22},
  [111] = {.lex_state = 22},
  [112] = {.lex_state = 22},
  [113] = {.lex_state = 22},
  [114] = {.lex_state = 22},
  [115] = {.lex_state = 22},
  [116] = {.lex_state = 22},
  [117] = {.lex_state = 22},
  [118] = {.lex_state = 22},
  [119] = {.lex_state = 22},
  [120] = {.lex_state = 22},
  [121] = {.lex_state = 22},
  [122] = {.lex_state = 22},
  [123] = {.lex_state = 20},
  [124] = {.lex_state = 22},
  [125] = {.lex_state = 22},
  [126] = {.lex_state = 22},
  [127] = {.lex_state = 22},
  [128] = {.lex_state = 22},
  [129] = {.lex_state = 22},
  [130] = {.lex_state = 22},
  [131] = {.lex_state = 22},
  [132] = {.lex_state = 22},
  [133] = {.lex_state = 22},
  [134] = {.lex_state = 22},
  [135] = {.lex_state = 22},
  [136] = {.lex_state = 22},
  [137] = {.lex_state = 22},
  [138] = {.lex_state = 22},
  [139] = {(TSStateId)(-1)},
  [140] = {(TSStateId)(-1)},
  [141] = {(TSStateId)(-1)},
};

static const uint16_t ts_parse_table[LARGE_STATE_COUNT][SYMBOL_COUNT] = {
  [0] = {
    [sym_comment] = STATE(0),
    [ts_builtin_sym_end] = ACTIONS(1),
    [anon_sym_COMMA] = ACTIONS(1),
    [anon_sym_AT] = ACTIONS(1),
    [anon_sym_EQ] = ACTIONS(1),
    [anon_sym_DASH] = ACTIONS(1),
    [anon_sym_PLUS] = ACTIONS(1),
    [anon_sym_STAR] = ACTIONS(1),
    [anon_sym_SLASH] = ACTIONS(1),
    [anon_sym_LPAREN] = ACTIONS(1),
    [anon_sym_RPAREN] = ACTIONS(1),
    [aux_sym__operand_symbol_token1] = ACTIONS(1),
    [anon_sym_COLON] = ACTIONS(1),
    [anon_sym_DOLLAR] = ACTIONS(1),
    [anon_sym_SQUOTE] = ACTIONS(1),
    [aux_sym_char_token1] = ACTIONS(1),
    [aux_sym_comment_token1] = ACTIONS(3),
    [anon_sym_SLASH_STAR] = ACTIONS(5),
    [aux_sym_comment_token2] = ACTIONS(1),
    [anon_sym_STAR_SLASH] = ACTIONS(1),
    [sym__inline_space] = ACTIONS(7),
  },
  [1] = {
    [sym_source_file] = STATE(122),
    [sym__statement] = STATE(117),
    [sym_directive] = STATE(114),
    [sym_assignment] = STATE(114),
    [sym_instruction] = STATE(114),
    [sym_instruction_prefix] = STATE(138),
    [sym_symbol] = STATE(68),
    [sym_comment] = STATE(1),
    [aux_sym_source_file_repeat1] = STATE(3),
    [ts_builtin_sym_end] = ACTIONS(9),
    [sym_label] = ACTIONS(11),
    [anon_sym_DOTfile] = ACTIONS(13),
    [anon_sym_DOTloc] = ACTIONS(13),
    [sym_directive_name] = ACTIONS(15),
    [aux_sym_instruction_prefix_token1] = ACTIONS(17),
    [aux_sym_instruction_prefix_token2] = ACTIONS(17),
    [aux_sym_instruction_prefix_token3] = ACTIONS(17),
    [aux_sym_instruction_prefix_token4] = ACTIONS(17),
    [aux_sym_instruction_prefix_token5] = ACTIONS(17),
    [aux_sym_instruction_prefix_token6] = ACTIONS(17),
    [aux_sym_instruction_prefix_token7] = ACTIONS(17),
    [aux_sym_instruction_prefix_token8] = ACTIONS(17),
    [aux_sym_instruction_prefix_token9] = ACTIONS(17),
    [aux_sym_instruction_prefix_token10] = ACTIONS(17),
    [sym__identifier] = ACTIONS(19),
    [aux_sym_comment_token1] = ACTIONS(21),
    [anon_sym_SLASH_STAR] = ACTIONS(5),
    [sym__inline_space] = ACTIONS(23),
    [sym__eol] = ACTIONS(25),
  },
};

static const uint16_t ts_small_parse_table[] = {
  [0] = 15,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(27), 1,
      ts_builtin_sym_end,
    ACTIONS(29), 1,
      sym_label,
    ACTIONS(35), 1,
      sym_directive_name,
    ACTIONS(41), 1,
      sym__identifier,
    ACTIONS(44), 1,
      sym__eol,
    STATE(68), 1,
      sym_symbol,
    STATE(128), 1,
      sym__statement,
    STATE(138), 1,
      sym_instruction_prefix,
    ACTIONS(32), 2,
      anon_sym_DOTfile,
      anon_sym_DOTloc,
    STATE(2), 2,
      sym_comment,
      aux_sym_source_file_repeat1,
    STATE(114), 3,
      sym_directive,
      sym_assignment,
      sym_instruction,
    ACTIONS(38), 10,
      aux_sym_instruction_prefix_token1,
      aux_sym_instruction_prefix_token2,
      aux_sym_instruction_prefix_token3,
      aux_sym_instruction_prefix_token4,
      aux_sym_instruction_prefix_token5,
      aux_sym_instruction_prefix_token6,
      aux_sym_instruction_prefix_token7,
      aux_sym_instruction_prefix_token8,
      aux_sym_instruction_prefix_token9,
      aux_sym_instruction_prefix_token10,
  [59] = 16,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(15), 1,
      sym_directive_name,
    ACTIONS(19), 1,
      sym__identifier,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(25), 1,
      sym__eol,
    ACTIONS(47), 1,
      ts_builtin_sym_end,
    ACTIONS(49), 1,
      sym_label,
    STATE(2), 1,
      aux_sym_source_file_repeat1,
    STATE(3), 1,
      sym_comment,
    STATE(68), 1,
      sym_symbol,
    STATE(106), 1,
      sym__statement,
    STATE(138), 1,
      sym_instruction_prefix,
    ACTIONS(13), 2,
      anon_sym_DOTfile,
      anon_sym_DOTloc,
    STATE(114), 3,
      sym_directive,
      sym_assignment,
      sym_instruction,
    ACTIONS(17), 10,
      aux_sym_instruction_prefix_token1,
      aux_sym_instruction_prefix_token2,
      aux_sym_instruction_prefix_token3,
      aux_sym_instruction_prefix_token4,
      aux_sym_instruction_prefix_token5,
      aux_sym_instruction_prefix_token6,
      aux_sym_instruction_prefix_token7,
      aux_sym_instruction_prefix_token8,
      aux_sym_instruction_prefix_token9,
      aux_sym_instruction_prefix_token10,
  [120] = 14,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(15), 1,
      sym_directive_name,
    ACTIONS(19), 1,
      sym__identifier,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(51), 1,
      ts_builtin_sym_end,
    ACTIONS(53), 1,
      sym__eol,
    STATE(4), 1,
      sym_comment,
    STATE(68), 1,
      sym_symbol,
    STATE(109), 1,
      sym__statement,
    STATE(138), 1,
      sym_instruction_prefix,
    ACTIONS(13), 2,
      anon_sym_DOTfile,
      anon_sym_DOTloc,
    STATE(114), 3,
      sym_directive,
      sym_assignment,
      sym_instruction,
    ACTIONS(17), 10,
      aux_sym_instruction_prefix_token1,
      aux_sym_instruction_prefix_token2,
      aux_sym_instruction_prefix_token3,
      aux_sym_instruction_prefix_token4,
      aux_sym_instruction_prefix_token5,
      aux_sym_instruction_prefix_token6,
      aux_sym_instruction_prefix_token7,
      aux_sym_instruction_prefix_token8,
      aux_sym_instruction_prefix_token9,
      aux_sym_instruction_prefix_token10,
  [175] = 14,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(15), 1,
      sym_directive_name,
    ACTIONS(19), 1,
      sym__identifier,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(47), 1,
      ts_builtin_sym_end,
    ACTIONS(53), 1,
      sym__eol,
    STATE(5), 1,
      sym_comment,
    STATE(68), 1,
      sym_symbol,
    STATE(118), 1,
      sym__statement,
    STATE(138), 1,
      sym_instruction_prefix,
    ACTIONS(13), 2,
      anon_sym_DOTfile,
      anon_sym_DOTloc,
    STATE(114), 3,
      sym_directive,
      sym_assignment,
      sym_instruction,
    ACTIONS(17), 10,
      aux_sym_instruction_prefix_token1,
      aux_sym_instruction_prefix_token2,
      aux_sym_instruction_prefix_token3,
      aux_sym_instruction_prefix_token4,
      aux_sym_instruction_prefix_token5,
      aux_sym_instruction_prefix_token6,
      aux_sym_instruction_prefix_token7,
      aux_sym_instruction_prefix_token8,
      aux_sym_instruction_prefix_token9,
      aux_sym_instruction_prefix_token10,
  [230] = 13,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(15), 1,
      sym_directive_name,
    ACTIONS(19), 1,
      sym__identifier,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(53), 1,
      sym__eol,
    STATE(6), 1,
      sym_comment,
    STATE(68), 1,
      sym_symbol,
    STATE(134), 1,
      sym__statement,
    STATE(138), 1,
      sym_instruction_prefix,
    ACTIONS(13), 2,
      anon_sym_DOTfile,
      anon_sym_DOTloc,
    STATE(114), 3,
      sym_directive,
      sym_assignment,
      sym_instruction,
    ACTIONS(17), 10,
      aux_sym_instruction_prefix_token1,
      aux_sym_instruction_prefix_token2,
      aux_sym_instruction_prefix_token3,
      aux_sym_instruction_prefix_token4,
      aux_sym_instruction_prefix_token5,
      aux_sym_instruction_prefix_token6,
      aux_sym_instruction_prefix_token7,
      aux_sym_instruction_prefix_token8,
      aux_sym_instruction_prefix_token9,
      aux_sym_instruction_prefix_token10,
  [282] = 17,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(57), 1,
      sym_local_label_reference,
    ACTIONS(59), 1,
      anon_sym_AT,
    ACTIONS(61), 1,
      anon_sym_LPAREN,
    ACTIONS(63), 1,
      anon_sym_SQUOTE,
    ACTIONS(65), 1,
      sym_string,
    ACTIONS(69), 1,
      sym__identifier,
    STATE(7), 1,
      sym_comment,
    STATE(36), 1,
      sym__sub_expression,
    STATE(43), 1,
      sym_expression,
    STATE(86), 1,
      sym__directive_arg,
    ACTIONS(67), 2,
      sym__integer,
      sym__float,
    STATE(78), 2,
      sym_type,
      sym_char,
    ACTIONS(55), 3,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      sym__eol,
    STATE(28), 3,
      sym__paren_expression,
      sym_number,
      sym_symbol,
  [340] = 16,
    ACTIONS(63), 1,
      anon_sym_SQUOTE,
    ACTIONS(71), 1,
      sym_local_label_reference,
    ACTIONS(75), 1,
      anon_sym_STAR,
    ACTIONS(77), 1,
      anon_sym_LPAREN,
    ACTIONS(79), 1,
      aux_sym__operand_symbol_token1,
    ACTIONS(81), 1,
      anon_sym_DOLLAR,
    ACTIONS(83), 1,
      sym_string,
    ACTIONS(85), 1,
      sym_register,
    STATE(8), 1,
      sym_comment,
    STATE(40), 1,
      sym__operand_expression,
    STATE(63), 1,
      sym__operand,
    STATE(135), 1,
      sym__displacement_expression_offset,
    ACTIONS(67), 2,
      sym__integer,
      sym__float,
    STATE(30), 2,
      sym__operand_symbol,
      sym_number,
    STATE(94), 3,
      sym__displacement_expression,
      sym_constant,
      sym_char,
    ACTIONS(73), 4,
      anon_sym_EQ,
      aux_sym_comment_token1,
      anon_sym_SLASH_STAR,
      sym__inline_space,
  [396] = 18,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(63), 1,
      anon_sym_SQUOTE,
    ACTIONS(71), 1,
      sym_local_label_reference,
    ACTIONS(77), 1,
      anon_sym_LPAREN,
    ACTIONS(79), 1,
      aux_sym__operand_symbol_token1,
    ACTIONS(81), 1,
      anon_sym_DOLLAR,
    ACTIONS(83), 1,
      sym_string,
    ACTIONS(85), 1,
      sym_register,
    ACTIONS(87), 1,
      anon_sym_STAR,
    STATE(9), 1,
      sym_comment,
    STATE(40), 1,
      sym__operand_expression,
    STATE(64), 1,
      sym__operand,
    STATE(135), 1,
      sym__displacement_expression_offset,
    ACTIONS(67), 2,
      sym__integer,
      sym__float,
    STATE(30), 2,
      sym__operand_symbol,
      sym_number,
    STATE(94), 3,
      sym__displacement_expression,
      sym_constant,
      sym_char,
  [455] = 17,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(63), 1,
      anon_sym_SQUOTE,
    ACTIONS(71), 1,
      sym_local_label_reference,
    ACTIONS(77), 1,
      anon_sym_LPAREN,
    ACTIONS(79), 1,
      aux_sym__operand_symbol_token1,
    ACTIONS(81), 1,
      anon_sym_DOLLAR,
    ACTIONS(83), 1,
      sym_string,
    ACTIONS(85), 1,
      sym_register,
    STATE(10), 1,
      sym_comment,
    STATE(40), 1,
      sym__operand_expression,
    STATE(71), 1,
      sym__operand,
    STATE(135), 1,
      sym__displacement_expression_offset,
    ACTIONS(67), 2,
      sym__integer,
      sym__float,
    STATE(30), 2,
      sym__operand_symbol,
      sym_number,
    STATE(94), 3,
      sym__displacement_expression,
      sym_constant,
      sym_char,
  [511] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    STATE(11), 1,
      sym_comment,
    ACTIONS(89), 3,
      ts_builtin_sym_end,
      sym_label,
      sym__eol,
    ACTIONS(91), 14,
      anon_sym_DOTfile,
      anon_sym_DOTloc,
      sym_directive_name,
      aux_sym_instruction_prefix_token1,
      aux_sym_instruction_prefix_token2,
      aux_sym_instruction_prefix_token3,
      aux_sym_instruction_prefix_token4,
      aux_sym_instruction_prefix_token5,
      aux_sym_instruction_prefix_token6,
      aux_sym_instruction_prefix_token7,
      aux_sym_instruction_prefix_token8,
      aux_sym_instruction_prefix_token9,
      aux_sym_instruction_prefix_token10,
      sym__identifier,
  [545] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    STATE(12), 1,
      sym_comment,
    ACTIONS(93), 3,
      ts_builtin_sym_end,
      sym_label,
      sym__eol,
    ACTIONS(95), 14,
      anon_sym_DOTfile,
      anon_sym_DOTloc,
      sym_directive_name,
      aux_sym_instruction_prefix_token1,
      aux_sym_instruction_prefix_token2,
      aux_sym_instruction_prefix_token3,
      aux_sym_instruction_prefix_token4,
      aux_sym_instruction_prefix_token5,
      aux_sym_instruction_prefix_token6,
      aux_sym_instruction_prefix_token7,
      aux_sym_instruction_prefix_token8,
      aux_sym_instruction_prefix_token9,
      aux_sym_instruction_prefix_token10,
      sym__identifier,
  [579] = 17,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(63), 1,
      anon_sym_SQUOTE,
    ACTIONS(71), 1,
      sym_local_label_reference,
    ACTIONS(77), 1,
      anon_sym_LPAREN,
    ACTIONS(79), 1,
      aux_sym__operand_symbol_token1,
    ACTIONS(81), 1,
      anon_sym_DOLLAR,
    ACTIONS(83), 1,
      sym_string,
    ACTIONS(85), 1,
      sym_register,
    STATE(13), 1,
      sym_comment,
    STATE(40), 1,
      sym__operand_expression,
    STATE(92), 1,
      sym__operand,
    STATE(135), 1,
      sym__displacement_expression_offset,
    ACTIONS(67), 2,
      sym__integer,
      sym__float,
    STATE(30), 2,
      sym__operand_symbol,
      sym_number,
    STATE(94), 3,
      sym__displacement_expression,
      sym_constant,
      sym_char,
  [635] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    STATE(14), 1,
      sym_comment,
    ACTIONS(27), 3,
      ts_builtin_sym_end,
      sym_label,
      sym__eol,
    ACTIONS(97), 14,
      anon_sym_DOTfile,
      anon_sym_DOTloc,
      sym_directive_name,
      aux_sym_instruction_prefix_token1,
      aux_sym_instruction_prefix_token2,
      aux_sym_instruction_prefix_token3,
      aux_sym_instruction_prefix_token4,
      aux_sym_instruction_prefix_token5,
      aux_sym_instruction_prefix_token6,
      aux_sym_instruction_prefix_token7,
      aux_sym_instruction_prefix_token8,
      aux_sym_instruction_prefix_token9,
      aux_sym_instruction_prefix_token10,
      sym__identifier,
  [669] = 17,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(63), 1,
      anon_sym_SQUOTE,
    ACTIONS(71), 1,
      sym_local_label_reference,
    ACTIONS(77), 1,
      anon_sym_LPAREN,
    ACTIONS(79), 1,
      aux_sym__operand_symbol_token1,
    ACTIONS(81), 1,
      anon_sym_DOLLAR,
    ACTIONS(83), 1,
      sym_string,
    ACTIONS(85), 1,
      sym_register,
    STATE(15), 1,
      sym_comment,
    STATE(40), 1,
      sym__operand_expression,
    STATE(67), 1,
      sym__operand,
    STATE(135), 1,
      sym__displacement_expression_offset,
    ACTIONS(67), 2,
      sym__integer,
      sym__float,
    STATE(30), 2,
      sym__operand_symbol,
      sym_number,
    STATE(94), 3,
      sym__displacement_expression,
      sym_constant,
      sym_char,
  [725] = 16,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(57), 1,
      sym_local_label_reference,
    ACTIONS(59), 1,
      anon_sym_AT,
    ACTIONS(61), 1,
      anon_sym_LPAREN,
    ACTIONS(63), 1,
      anon_sym_SQUOTE,
    ACTIONS(65), 1,
      sym_string,
    ACTIONS(69), 1,
      sym__identifier,
    STATE(16), 1,
      sym_comment,
    STATE(36), 1,
      sym__sub_expression,
    STATE(43), 1,
      sym_expression,
    STATE(58), 1,
      sym__directive_arg,
    ACTIONS(67), 2,
      sym__integer,
      sym__float,
    STATE(78), 2,
      sym_type,
      sym_char,
    STATE(28), 3,
      sym__paren_expression,
      sym_number,
      sym_symbol,
  [778] = 14,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(57), 1,
      sym_local_label_reference,
    ACTIONS(61), 1,
      anon_sym_LPAREN,
    ACTIONS(63), 1,
      anon_sym_SQUOTE,
    ACTIONS(69), 1,
      sym__identifier,
    ACTIONS(99), 1,
      sym_string,
    STATE(17), 1,
      sym_comment,
    STATE(36), 1,
      sym__sub_expression,
    STATE(46), 1,
      sym_expression,
    STATE(75), 1,
      sym_char,
    ACTIONS(67), 2,
      sym__integer,
      sym__float,
    STATE(28), 3,
      sym__paren_expression,
      sym_number,
      sym_symbol,
  [824] = 11,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(57), 1,
      sym_local_label_reference,
    ACTIONS(61), 1,
      anon_sym_LPAREN,
    ACTIONS(69), 1,
      sym__identifier,
    STATE(18), 1,
      sym_comment,
    STATE(36), 1,
      sym__sub_expression,
    STATE(49), 1,
      sym_expression,
    ACTIONS(67), 2,
      sym__integer,
      sym__float,
    STATE(28), 3,
      sym__paren_expression,
      sym_number,
      sym_symbol,
  [861] = 11,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(57), 1,
      sym_local_label_reference,
    ACTIONS(61), 1,
      anon_sym_LPAREN,
    ACTIONS(69), 1,
      sym__identifier,
    STATE(19), 1,
      sym_comment,
    STATE(36), 1,
      sym__sub_expression,
    STATE(53), 1,
      sym_expression,
    ACTIONS(67), 2,
      sym__integer,
      sym__float,
    STATE(28), 3,
      sym__paren_expression,
      sym_number,
      sym_symbol,
  [898] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(103), 1,
      anon_sym_SLASH,
    STATE(20), 1,
      sym_comment,
    ACTIONS(101), 9,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      anon_sym_EQ,
      anon_sym_DASH,
      anon_sym_PLUS,
      anon_sym_STAR,
      anon_sym_LPAREN,
      anon_sym_RPAREN,
      sym__eol,
  [925] = 11,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(57), 1,
      sym_local_label_reference,
    ACTIONS(61), 1,
      anon_sym_LPAREN,
    ACTIONS(69), 1,
      sym__identifier,
    STATE(21), 1,
      sym_comment,
    STATE(25), 1,
      sym_expression,
    STATE(36), 1,
      sym__sub_expression,
    ACTIONS(67), 2,
      sym__integer,
      sym__float,
    STATE(28), 3,
      sym__paren_expression,
      sym_number,
      sym_symbol,
  [962] = 7,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(107), 1,
      anon_sym_SLASH,
    ACTIONS(109), 1,
      sym_operand_modifier,
    STATE(22), 1,
      sym_comment,
    ACTIONS(105), 8,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      anon_sym_DASH,
      anon_sym_PLUS,
      anon_sym_STAR,
      anon_sym_LPAREN,
      anon_sym_RPAREN,
      sym__eol,
  [991] = 11,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(57), 1,
      sym_local_label_reference,
    ACTIONS(61), 1,
      anon_sym_LPAREN,
    ACTIONS(69), 1,
      sym__identifier,
    STATE(23), 1,
      sym_comment,
    STATE(36), 1,
      sym__sub_expression,
    STATE(50), 1,
      sym_expression,
    ACTIONS(67), 2,
      sym__integer,
      sym__float,
    STATE(28), 3,
      sym__paren_expression,
      sym_number,
      sym_symbol,
  [1028] = 11,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(71), 1,
      sym_local_label_reference,
    ACTIONS(79), 1,
      aux_sym__operand_symbol_token1,
    ACTIONS(111), 1,
      sym_register,
    STATE(24), 1,
      sym_comment,
    STATE(31), 1,
      sym__operand_expression,
    STATE(127), 1,
      sym__displacement_expression_offset,
    ACTIONS(67), 2,
      sym__integer,
      sym__float,
    STATE(30), 2,
      sym__operand_symbol,
      sym_number,
  [1064] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(115), 1,
      anon_sym_SLASH,
    STATE(25), 1,
      sym_comment,
    ACTIONS(113), 8,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      anon_sym_EQ,
      anon_sym_DASH,
      anon_sym_PLUS,
      anon_sym_STAR,
      anon_sym_RPAREN,
      sym__eol,
  [1090] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(119), 1,
      anon_sym_SLASH,
    STATE(26), 1,
      sym_comment,
    ACTIONS(117), 8,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      anon_sym_EQ,
      anon_sym_DASH,
      anon_sym_PLUS,
      anon_sym_STAR,
      anon_sym_RPAREN,
      sym__eol,
  [1116] = 11,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(71), 1,
      sym_local_label_reference,
    ACTIONS(79), 1,
      aux_sym__operand_symbol_token1,
    ACTIONS(121), 1,
      sym_register,
    STATE(27), 1,
      sym_comment,
    STATE(31), 1,
      sym__operand_expression,
    STATE(125), 1,
      sym__displacement_expression_offset,
    ACTIONS(67), 2,
      sym__integer,
      sym__float,
    STATE(30), 2,
      sym__operand_symbol,
      sym_number,
  [1152] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(125), 1,
      anon_sym_SLASH,
    STATE(28), 1,
      sym_comment,
    ACTIONS(123), 8,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      anon_sym_EQ,
      anon_sym_DASH,
      anon_sym_PLUS,
      anon_sym_STAR,
      anon_sym_RPAREN,
      sym__eol,
  [1178] = 11,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(71), 1,
      sym_local_label_reference,
    ACTIONS(79), 1,
      aux_sym__operand_symbol_token1,
    ACTIONS(127), 1,
      sym_register,
    STATE(29), 1,
      sym_comment,
    STATE(31), 1,
      sym__operand_expression,
    STATE(124), 1,
      sym__displacement_expression_offset,
    ACTIONS(67), 2,
      sym__integer,
      sym__float,
    STATE(30), 2,
      sym__operand_symbol,
      sym_number,
  [1214] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(131), 1,
      anon_sym_SLASH,
    STATE(30), 1,
      sym_comment,
    ACTIONS(129), 8,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      anon_sym_DASH,
      anon_sym_PLUS,
      anon_sym_STAR,
      anon_sym_LPAREN,
      anon_sym_RPAREN,
      sym__eol,
  [1240] = 7,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(137), 1,
      anon_sym_SLASH,
    STATE(31), 1,
      sym_comment,
    ACTIONS(135), 3,
      anon_sym_DASH,
      anon_sym_PLUS,
      anon_sym_STAR,
    ACTIONS(133), 5,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      anon_sym_LPAREN,
      anon_sym_RPAREN,
      sym__eol,
  [1268] = 11,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(71), 1,
      sym_local_label_reference,
    ACTIONS(79), 1,
      aux_sym__operand_symbol_token1,
    ACTIONS(139), 1,
      anon_sym_LPAREN,
    STATE(31), 1,
      sym__operand_expression,
    STATE(32), 1,
      sym_comment,
    STATE(57), 1,
      sym__displacement_expression_offset,
    ACTIONS(67), 2,
      sym__integer,
      sym__float,
    STATE(30), 2,
      sym__operand_symbol,
      sym_number,
  [1304] = 11,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(71), 1,
      sym_local_label_reference,
    ACTIONS(79), 1,
      aux_sym__operand_symbol_token1,
    ACTIONS(141), 1,
      sym_register,
    STATE(31), 1,
      sym__operand_expression,
    STATE(33), 1,
      sym_comment,
    STATE(131), 1,
      sym__displacement_expression_offset,
    ACTIONS(67), 2,
      sym__integer,
      sym__float,
    STATE(30), 2,
      sym__operand_symbol,
      sym_number,
  [1340] = 11,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(71), 1,
      sym_local_label_reference,
    ACTIONS(79), 1,
      aux_sym__operand_symbol_token1,
    ACTIONS(143), 1,
      sym_register,
    STATE(31), 1,
      sym__operand_expression,
    STATE(34), 1,
      sym_comment,
    STATE(136), 1,
      sym__displacement_expression_offset,
    ACTIONS(67), 2,
      sym__integer,
      sym__float,
    STATE(30), 2,
      sym__operand_symbol,
      sym_number,
  [1376] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(147), 1,
      anon_sym_SLASH,
    STATE(35), 1,
      sym_comment,
    ACTIONS(145), 8,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      anon_sym_DASH,
      anon_sym_PLUS,
      anon_sym_STAR,
      anon_sym_LPAREN,
      anon_sym_RPAREN,
      sym__eol,
  [1402] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(151), 1,
      anon_sym_SLASH,
    STATE(36), 1,
      sym_comment,
    ACTIONS(149), 8,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      anon_sym_EQ,
      anon_sym_DASH,
      anon_sym_PLUS,
      anon_sym_STAR,
      anon_sym_RPAREN,
      sym__eol,
  [1428] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(155), 1,
      anon_sym_SLASH,
    STATE(37), 1,
      sym_comment,
    ACTIONS(153), 8,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      anon_sym_DASH,
      anon_sym_PLUS,
      anon_sym_STAR,
      anon_sym_LPAREN,
      anon_sym_RPAREN,
      sym__eol,
  [1454] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(159), 1,
      anon_sym_SLASH,
    STATE(38), 1,
      sym_comment,
    ACTIONS(157), 8,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      anon_sym_EQ,
      anon_sym_DASH,
      anon_sym_PLUS,
      anon_sym_STAR,
      anon_sym_RPAREN,
      sym__eol,
  [1480] = 10,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(71), 1,
      sym_local_label_reference,
    ACTIONS(79), 1,
      aux_sym__operand_symbol_token1,
    STATE(31), 1,
      sym__operand_expression,
    STATE(39), 1,
      sym_comment,
    STATE(124), 1,
      sym__displacement_expression_offset,
    ACTIONS(67), 2,
      sym__integer,
      sym__float,
    STATE(30), 2,
      sym__operand_symbol,
      sym_number,
  [1513] = 8,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(133), 1,
      anon_sym_LPAREN,
    ACTIONS(137), 1,
      anon_sym_SLASH,
    STATE(40), 1,
      sym_comment,
    ACTIONS(135), 3,
      anon_sym_DASH,
      anon_sym_PLUS,
      anon_sym_STAR,
    ACTIONS(161), 3,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      sym__eol,
  [1542] = 10,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(71), 1,
      sym_local_label_reference,
    ACTIONS(79), 1,
      aux_sym__operand_symbol_token1,
    STATE(31), 1,
      sym__operand_expression,
    STATE(41), 1,
      sym_comment,
    STATE(127), 1,
      sym__displacement_expression_offset,
    ACTIONS(67), 2,
      sym__integer,
      sym__float,
    STATE(30), 2,
      sym__operand_symbol,
      sym_number,
  [1575] = 9,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(165), 1,
      sym_string,
    ACTIONS(169), 1,
      sym__identifier,
    STATE(42), 1,
      sym_comment,
    ACTIONS(163), 2,
      ts_builtin_sym_end,
      sym__eol,
    ACTIONS(167), 2,
      sym__integer,
      sym__float,
    STATE(119), 2,
      sym_number,
      sym_symbol,
  [1606] = 7,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(175), 1,
      anon_sym_SLASH,
    STATE(43), 1,
      sym_comment,
    ACTIONS(171), 3,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      sym__eol,
    ACTIONS(173), 4,
      anon_sym_EQ,
      anon_sym_DASH,
      anon_sym_PLUS,
      anon_sym_STAR,
  [1633] = 10,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(71), 1,
      sym_local_label_reference,
    ACTIONS(79), 1,
      aux_sym__operand_symbol_token1,
    STATE(31), 1,
      sym__operand_expression,
    STATE(44), 1,
      sym_comment,
    STATE(129), 1,
      sym__displacement_expression_offset,
    ACTIONS(67), 2,
      sym__integer,
      sym__float,
    STATE(30), 2,
      sym__operand_symbol,
      sym_number,
  [1666] = 10,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(71), 1,
      sym_local_label_reference,
    ACTIONS(79), 1,
      aux_sym__operand_symbol_token1,
    STATE(31), 1,
      sym__operand_expression,
    STATE(45), 1,
      sym_comment,
    STATE(126), 1,
      sym__displacement_expression_offset,
    ACTIONS(67), 2,
      sym__integer,
      sym__float,
    STATE(30), 2,
      sym__operand_symbol,
      sym_number,
  [1699] = 7,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(175), 1,
      anon_sym_SLASH,
    STATE(46), 1,
      sym_comment,
    ACTIONS(177), 3,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      sym__eol,
    ACTIONS(173), 4,
      anon_sym_EQ,
      anon_sym_DASH,
      anon_sym_PLUS,
      anon_sym_STAR,
  [1726] = 9,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(165), 1,
      sym_string,
    ACTIONS(169), 1,
      sym__identifier,
    STATE(47), 1,
      sym_comment,
    ACTIONS(167), 2,
      sym__integer,
      sym__float,
    ACTIONS(179), 2,
      ts_builtin_sym_end,
      sym__eol,
    STATE(119), 2,
      sym_number,
      sym_symbol,
  [1757] = 10,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(71), 1,
      sym_local_label_reference,
    ACTIONS(79), 1,
      aux_sym__operand_symbol_token1,
    STATE(31), 1,
      sym__operand_expression,
    STATE(48), 1,
      sym_comment,
    STATE(125), 1,
      sym__displacement_expression_offset,
    ACTIONS(67), 2,
      sym__integer,
      sym__float,
    STATE(30), 2,
      sym__operand_symbol,
      sym_number,
  [1790] = 7,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(175), 1,
      anon_sym_SLASH,
    STATE(49), 1,
      sym_comment,
    ACTIONS(181), 2,
      ts_builtin_sym_end,
      sym__eol,
    ACTIONS(173), 4,
      anon_sym_EQ,
      anon_sym_DASH,
      anon_sym_PLUS,
      anon_sym_STAR,
  [1816] = 7,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(175), 1,
      anon_sym_SLASH,
    STATE(50), 1,
      sym_comment,
    ACTIONS(183), 2,
      ts_builtin_sym_end,
      sym__eol,
    ACTIONS(173), 4,
      anon_sym_EQ,
      anon_sym_DASH,
      anon_sym_PLUS,
      anon_sym_STAR,
  [1842] = 9,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(71), 1,
      sym_local_label_reference,
    ACTIONS(79), 1,
      aux_sym__operand_symbol_token1,
    STATE(37), 1,
      sym__operand_expression,
    STATE(51), 1,
      sym_comment,
    ACTIONS(67), 2,
      sym__integer,
      sym__float,
    STATE(30), 2,
      sym__operand_symbol,
      sym_number,
  [1872] = 8,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(165), 1,
      sym_string,
    ACTIONS(169), 1,
      sym__identifier,
    STATE(52), 1,
      sym_comment,
    ACTIONS(167), 2,
      sym__integer,
      sym__float,
    STATE(119), 2,
      sym_number,
      sym_symbol,
  [1899] = 7,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(175), 1,
      anon_sym_SLASH,
    ACTIONS(185), 1,
      anon_sym_RPAREN,
    STATE(53), 1,
      sym_comment,
    ACTIONS(173), 4,
      anon_sym_EQ,
      anon_sym_DASH,
      anon_sym_PLUS,
      anon_sym_STAR,
  [1924] = 7,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(189), 1,
      anon_sym_COMMA,
    STATE(54), 1,
      sym_comment,
    STATE(65), 1,
      aux_sym_instruction_repeat1,
    ACTIONS(187), 2,
      ts_builtin_sym_end,
      sym__eol,
  [1947] = 7,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(7), 1,
      sym__inline_space,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(193), 1,
      anon_sym_STAR_SLASH,
    STATE(55), 1,
      sym_comment,
    STATE(74), 1,
      aux_sym_comment_repeat1,
    ACTIONS(191), 2,
      aux_sym_comment_token2,
      sym__eol,
  [1970] = 7,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(7), 1,
      sym__inline_space,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(195), 1,
      anon_sym_STAR_SLASH,
    STATE(56), 1,
      sym_comment,
    STATE(74), 1,
      aux_sym_comment_repeat1,
    ACTIONS(191), 2,
      aux_sym_comment_token2,
      sym__eol,
  [1993] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(199), 1,
      anon_sym_LPAREN,
    STATE(57), 1,
      sym_comment,
    ACTIONS(197), 3,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      sym__eol,
  [2014] = 7,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(201), 1,
      anon_sym_COMMA,
    STATE(58), 1,
      sym_comment,
    STATE(70), 1,
      aux_sym_directive_repeat1,
    ACTIONS(163), 2,
      ts_builtin_sym_end,
      sym__eol,
  [2037] = 7,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(7), 1,
      sym__inline_space,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(203), 1,
      anon_sym_STAR_SLASH,
    STATE(56), 1,
      aux_sym_comment_repeat1,
    STATE(59), 1,
      sym_comment,
    ACTIONS(191), 2,
      aux_sym_comment_token2,
      sym__eol,
  [2060] = 7,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(7), 1,
      sym__inline_space,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(205), 1,
      anon_sym_STAR_SLASH,
    STATE(55), 1,
      aux_sym_comment_repeat1,
    STATE(60), 1,
      sym_comment,
    ACTIONS(191), 2,
      aux_sym_comment_token2,
      sym__eol,
  [2083] = 7,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(189), 1,
      anon_sym_COMMA,
    STATE(61), 1,
      sym_comment,
    STATE(65), 1,
      aux_sym_instruction_repeat1,
    ACTIONS(207), 2,
      ts_builtin_sym_end,
      sym__eol,
  [2106] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(209), 1,
      anon_sym_COLON,
    STATE(62), 1,
      sym_comment,
    ACTIONS(161), 3,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      sym__eol,
  [2127] = 7,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(189), 1,
      anon_sym_COMMA,
    STATE(63), 1,
      sym_comment,
    STATE(73), 1,
      aux_sym_instruction_repeat1,
    ACTIONS(211), 2,
      ts_builtin_sym_end,
      sym__eol,
  [2150] = 7,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(189), 1,
      anon_sym_COMMA,
    STATE(54), 1,
      aux_sym_instruction_repeat1,
    STATE(64), 1,
      sym_comment,
    ACTIONS(213), 2,
      ts_builtin_sym_end,
      sym__eol,
  [2173] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(217), 1,
      anon_sym_COMMA,
    ACTIONS(215), 2,
      ts_builtin_sym_end,
      sym__eol,
    STATE(65), 2,
      sym_comment,
      aux_sym_instruction_repeat1,
  [2194] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(222), 1,
      anon_sym_COMMA,
    ACTIONS(220), 2,
      ts_builtin_sym_end,
      sym__eol,
    STATE(66), 2,
      sym_comment,
      aux_sym_directive_repeat1,
  [2215] = 7,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(189), 1,
      anon_sym_COMMA,
    STATE(67), 1,
      sym_comment,
    STATE(72), 1,
      aux_sym_instruction_repeat1,
    ACTIONS(187), 2,
      ts_builtin_sym_end,
      sym__eol,
  [2238] = 7,
    ACTIONS(227), 1,
      anon_sym_EQ,
    ACTIONS(229), 1,
      aux_sym_comment_token1,
    ACTIONS(231), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(233), 1,
      sym__inline_space,
    STATE(68), 1,
      sym_comment,
    STATE(104), 1,
      aux_sym_assignment_repeat1,
    ACTIONS(225), 2,
      ts_builtin_sym_end,
      sym__eol,
  [2261] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(237), 1,
      anon_sym_SQUOTE,
    STATE(69), 1,
      sym_comment,
    ACTIONS(235), 3,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      sym__eol,
  [2282] = 7,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(201), 1,
      anon_sym_COMMA,
    STATE(66), 1,
      aux_sym_directive_repeat1,
    STATE(70), 1,
      sym_comment,
    ACTIONS(239), 2,
      ts_builtin_sym_end,
      sym__eol,
  [2305] = 7,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(189), 1,
      anon_sym_COMMA,
    STATE(61), 1,
      aux_sym_instruction_repeat1,
    STATE(71), 1,
      sym_comment,
    ACTIONS(241), 2,
      ts_builtin_sym_end,
      sym__eol,
  [2328] = 7,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(189), 1,
      anon_sym_COMMA,
    STATE(65), 1,
      aux_sym_instruction_repeat1,
    STATE(72), 1,
      sym_comment,
    ACTIONS(243), 2,
      ts_builtin_sym_end,
      sym__eol,
  [2351] = 7,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(189), 1,
      anon_sym_COMMA,
    STATE(65), 1,
      aux_sym_instruction_repeat1,
    STATE(73), 1,
      sym_comment,
    ACTIONS(241), 2,
      ts_builtin_sym_end,
      sym__eol,
  [2374] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(7), 1,
      sym__inline_space,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(248), 1,
      anon_sym_STAR_SLASH,
    ACTIONS(245), 2,
      aux_sym_comment_token2,
      sym__eol,
    STATE(74), 2,
      sym_comment,
      aux_sym_comment_repeat1,
  [2395] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    STATE(75), 1,
      sym_comment,
    ACTIONS(177), 3,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      sym__eol,
  [2413] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    STATE(76), 1,
      sym_comment,
    ACTIONS(250), 3,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      sym__eol,
  [2431] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    STATE(77), 1,
      sym_comment,
    ACTIONS(252), 3,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      sym__eol,
  [2449] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    STATE(78), 1,
      sym_comment,
    ACTIONS(171), 3,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      sym__eol,
  [2467] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(256), 1,
      sym__inline_space,
    ACTIONS(254), 2,
      ts_builtin_sym_end,
      sym__eol,
    STATE(79), 2,
      sym_comment,
      aux_sym_directive_repeat2,
  [2485] = 2,
    STATE(80), 1,
      sym_comment,
    ACTIONS(157), 6,
      ts_builtin_sym_end,
      anon_sym_EQ,
      aux_sym_comment_token1,
      anon_sym_SLASH_STAR,
      sym__inline_space,
      sym__eol,
  [2497] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    STATE(81), 1,
      sym_comment,
    ACTIONS(259), 3,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      sym__eol,
  [2515] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    STATE(82), 1,
      sym_comment,
    ACTIONS(261), 3,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      sym__eol,
  [2533] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(7), 1,
      sym__inline_space,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(265), 1,
      anon_sym_STAR_SLASH,
    STATE(83), 1,
      sym_comment,
    ACTIONS(263), 2,
      aux_sym_comment_token2,
      sym__eol,
  [2553] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    STATE(84), 1,
      sym_comment,
    ACTIONS(267), 3,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      sym__eol,
  [2571] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    STATE(85), 1,
      sym_comment,
    ACTIONS(269), 3,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      sym__eol,
  [2589] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    STATE(86), 1,
      sym_comment,
    ACTIONS(220), 3,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      sym__eol,
  [2607] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    STATE(87), 1,
      sym_comment,
    ACTIONS(271), 3,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      sym__eol,
  [2625] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    STATE(88), 1,
      sym_comment,
    ACTIONS(273), 3,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      sym__eol,
  [2643] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(275), 1,
      sym__inline_space,
    STATE(79), 1,
      aux_sym_directive_repeat2,
    STATE(89), 1,
      sym_comment,
    ACTIONS(179), 2,
      ts_builtin_sym_end,
      sym__eol,
  [2663] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    STATE(90), 1,
      sym_comment,
    ACTIONS(277), 3,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      sym__eol,
  [2681] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(281), 1,
      sym__inline_space,
    STATE(89), 1,
      aux_sym_directive_repeat2,
    STATE(91), 1,
      sym_comment,
    ACTIONS(279), 2,
      ts_builtin_sym_end,
      sym__eol,
  [2701] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    STATE(92), 1,
      sym_comment,
    ACTIONS(215), 3,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      sym__eol,
  [2719] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    STATE(93), 1,
      sym_comment,
    ACTIONS(197), 3,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      sym__eol,
  [2737] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    STATE(94), 1,
      sym_comment,
    ACTIONS(161), 3,
      ts_builtin_sym_end,
      anon_sym_COMMA,
      sym__eol,
  [2755] = 4,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    STATE(95), 1,
      sym_comment,
    ACTIONS(101), 3,
      ts_builtin_sym_end,
      sym__inline_space,
      sym__eol,
  [2770] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(283), 1,
      anon_sym_COMMA,
    ACTIONS(285), 1,
      anon_sym_RPAREN,
    STATE(96), 1,
      sym_comment,
  [2789] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(289), 1,
      sym__inline_space,
    STATE(97), 1,
      sym_comment,
    ACTIONS(287), 2,
      ts_builtin_sym_end,
      sym__eol,
  [2806] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(291), 1,
      anon_sym_COMMA,
    ACTIONS(293), 1,
      sym_register,
    STATE(98), 1,
      sym_comment,
  [2825] = 6,
    ACTIONS(3), 1,
      aux_sym_comment_token1,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(7), 1,
      sym__inline_space,
    ACTIONS(295), 1,
      aux_sym_char_token1,
    ACTIONS(297), 1,
      sym__character_escapes,
    STATE(99), 1,
      sym_comment,
  [2844] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(299), 1,
      anon_sym_COMMA,
    ACTIONS(301), 1,
      anon_sym_RPAREN,
    STATE(100), 1,
      sym_comment,
  [2863] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(303), 1,
      anon_sym_COMMA,
    ACTIONS(305), 1,
      sym_register,
    STATE(101), 1,
      sym_comment,
  [2882] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(291), 1,
      anon_sym_COMMA,
    ACTIONS(301), 1,
      anon_sym_RPAREN,
    STATE(102), 1,
      sym_comment,
  [2901] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(169), 1,
      sym__identifier,
    STATE(97), 1,
      sym_symbol,
    STATE(103), 1,
      sym_comment,
  [2920] = 6,
    ACTIONS(229), 1,
      aux_sym_comment_token1,
    ACTIONS(231), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(307), 1,
      anon_sym_EQ,
    ACTIONS(309), 1,
      sym__inline_space,
    STATE(104), 1,
      sym_comment,
    STATE(105), 1,
      aux_sym_assignment_repeat1,
  [2939] = 5,
    ACTIONS(311), 1,
      anon_sym_EQ,
    ACTIONS(313), 1,
      aux_sym_comment_token1,
    ACTIONS(316), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(319), 1,
      sym__inline_space,
    STATE(105), 2,
      sym_comment,
      aux_sym_assignment_repeat1,
  [2956] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(51), 1,
      ts_builtin_sym_end,
    ACTIONS(53), 1,
      sym__eol,
    STATE(106), 1,
      sym_comment,
  [2975] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(322), 1,
      anon_sym_COMMA,
    ACTIONS(324), 1,
      anon_sym_RPAREN,
    STATE(107), 1,
      sym_comment,
  [2994] = 4,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    STATE(108), 1,
      sym_comment,
    ACTIONS(157), 3,
      ts_builtin_sym_end,
      sym__inline_space,
      sym__eol,
  [3009] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(326), 1,
      ts_builtin_sym_end,
    ACTIONS(328), 1,
      sym__eol,
    STATE(109), 1,
      sym_comment,
  [3028] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(324), 1,
      anon_sym_RPAREN,
    ACTIONS(330), 1,
      anon_sym_COMMA,
    STATE(110), 1,
      sym_comment,
  [3047] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(330), 1,
      anon_sym_COMMA,
    ACTIONS(332), 1,
      sym_register,
    STATE(111), 1,
      sym_comment,
  [3066] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(334), 1,
      anon_sym_COMMA,
    ACTIONS(336), 1,
      sym_register,
    STATE(112), 1,
      sym_comment,
  [3085] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(338), 1,
      sym__inline_space,
    STATE(113), 1,
      sym_comment,
    ACTIONS(279), 2,
      ts_builtin_sym_end,
      sym__eol,
  [3102] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    STATE(114), 1,
      sym_comment,
    ACTIONS(340), 2,
      ts_builtin_sym_end,
      sym__eol,
  [3119] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(342), 1,
      anon_sym_COMMA,
    ACTIONS(344), 1,
      anon_sym_RPAREN,
    STATE(115), 1,
      sym_comment,
  [3138] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(285), 1,
      anon_sym_RPAREN,
    ACTIONS(346), 1,
      anon_sym_COMMA,
    STATE(116), 1,
      sym_comment,
  [3157] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(47), 1,
      ts_builtin_sym_end,
    ACTIONS(53), 1,
      sym__eol,
    STATE(117), 1,
      sym_comment,
  [3176] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(51), 1,
      ts_builtin_sym_end,
    ACTIONS(328), 1,
      sym__eol,
    STATE(118), 1,
      sym_comment,
  [3195] = 4,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    STATE(119), 1,
      sym_comment,
    ACTIONS(254), 3,
      ts_builtin_sym_end,
      sym__inline_space,
      sym__eol,
  [3210] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(334), 1,
      anon_sym_COMMA,
    ACTIONS(348), 1,
      anon_sym_RPAREN,
    STATE(120), 1,
      sym_comment,
  [3229] = 6,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(350), 1,
      anon_sym_COMMA,
    ACTIONS(352), 1,
      anon_sym_RPAREN,
    STATE(121), 1,
      sym_comment,
  [3248] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(354), 1,
      ts_builtin_sym_end,
    STATE(122), 1,
      sym_comment,
  [3264] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(356), 1,
      sym__identifier,
    STATE(123), 1,
      sym_comment,
  [3280] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(352), 1,
      anon_sym_RPAREN,
    STATE(124), 1,
      sym_comment,
  [3296] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(344), 1,
      anon_sym_RPAREN,
    STATE(125), 1,
      sym_comment,
  [3312] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(358), 1,
      anon_sym_RPAREN,
    STATE(126), 1,
      sym_comment,
  [3328] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(285), 1,
      anon_sym_RPAREN,
    STATE(127), 1,
      sym_comment,
  [3344] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(53), 1,
      sym__eol,
    STATE(128), 1,
      sym_comment,
  [3360] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(360), 1,
      anon_sym_RPAREN,
    STATE(129), 1,
      sym_comment,
  [3376] = 2,
    STATE(130), 1,
      sym_comment,
    ACTIONS(362), 4,
      anon_sym_EQ,
      aux_sym_comment_token1,
      anon_sym_SLASH_STAR,
      sym__inline_space,
  [3386] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(324), 1,
      anon_sym_RPAREN,
    STATE(131), 1,
      sym_comment,
  [3402] = 2,
    STATE(132), 1,
      sym_comment,
    ACTIONS(364), 4,
      anon_sym_EQ,
      aux_sym_comment_token1,
      anon_sym_SLASH_STAR,
      sym__inline_space,
  [3412] = 2,
    STATE(133), 1,
      sym_comment,
    ACTIONS(366), 4,
      anon_sym_EQ,
      aux_sym_comment_token1,
      anon_sym_SLASH_STAR,
      sym__inline_space,
  [3422] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(328), 1,
      sym__eol,
    STATE(134), 1,
      sym_comment,
  [3438] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(368), 1,
      anon_sym_LPAREN,
    STATE(135), 1,
      sym_comment,
  [3454] = 5,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(23), 1,
      sym__inline_space,
    ACTIONS(301), 1,
      anon_sym_RPAREN,
    STATE(136), 1,
      sym_comment,
  [3470] = 4,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(370), 1,
      sym__inline_space,
    STATE(137), 1,
      sym_comment,
  [3483] = 4,
    ACTIONS(5), 1,
      anon_sym_SLASH_STAR,
    ACTIONS(21), 1,
      aux_sym_comment_token1,
    ACTIONS(372), 1,
      sym__inline_space,
    STATE(138), 1,
      sym_comment,
  [3496] = 1,
    ACTIONS(366), 1,
      ts_builtin_sym_end,
  [3500] = 1,
    ACTIONS(362), 1,
      ts_builtin_sym_end,
  [3504] = 1,
    ACTIONS(364), 1,
      ts_builtin_sym_end,
};

static const uint32_t ts_small_parse_table_map[] = {
  [SMALL_STATE(2)] = 0,
  [SMALL_STATE(3)] = 59,
  [SMALL_STATE(4)] = 120,
  [SMALL_STATE(5)] = 175,
  [SMALL_STATE(6)] = 230,
  [SMALL_STATE(7)] = 282,
  [SMALL_STATE(8)] = 340,
  [SMALL_STATE(9)] = 396,
  [SMALL_STATE(10)] = 455,
  [SMALL_STATE(11)] = 511,
  [SMALL_STATE(12)] = 545,
  [SMALL_STATE(13)] = 579,
  [SMALL_STATE(14)] = 635,
  [SMALL_STATE(15)] = 669,
  [SMALL_STATE(16)] = 725,
  [SMALL_STATE(17)] = 778,
  [SMALL_STATE(18)] = 824,
  [SMALL_STATE(19)] = 861,
  [SMALL_STATE(20)] = 898,
  [SMALL_STATE(21)] = 925,
  [SMALL_STATE(22)] = 962,
  [SMALL_STATE(23)] = 991,
  [SMALL_STATE(24)] = 1028,
  [SMALL_STATE(25)] = 1064,
  [SMALL_STATE(26)] = 1090,
  [SMALL_STATE(27)] = 1116,
  [SMALL_STATE(28)] = 1152,
  [SMALL_STATE(29)] = 1178,
  [SMALL_STATE(30)] = 1214,
  [SMALL_STATE(31)] = 1240,
  [SMALL_STATE(32)] = 1268,
  [SMALL_STATE(33)] = 1304,
  [SMALL_STATE(34)] = 1340,
  [SMALL_STATE(35)] = 1376,
  [SMALL_STATE(36)] = 1402,
  [SMALL_STATE(37)] = 1428,
  [SMALL_STATE(38)] = 1454,
  [SMALL_STATE(39)] = 1480,
  [SMALL_STATE(40)] = 1513,
  [SMALL_STATE(41)] = 1542,
  [SMALL_STATE(42)] = 1575,
  [SMALL_STATE(43)] = 1606,
  [SMALL_STATE(44)] = 1633,
  [SMALL_STATE(45)] = 1666,
  [SMALL_STATE(46)] = 1699,
  [SMALL_STATE(47)] = 1726,
  [SMALL_STATE(48)] = 1757,
  [SMALL_STATE(49)] = 1790,
  [SMALL_STATE(50)] = 1816,
  [SMALL_STATE(51)] = 1842,
  [SMALL_STATE(52)] = 1872,
  [SMALL_STATE(53)] = 1899,
  [SMALL_STATE(54)] = 1924,
  [SMALL_STATE(55)] = 1947,
  [SMALL_STATE(56)] = 1970,
  [SMALL_STATE(57)] = 1993,
  [SMALL_STATE(58)] = 2014,
  [SMALL_STATE(59)] = 2037,
  [SMALL_STATE(60)] = 2060,
  [SMALL_STATE(61)] = 2083,
  [SMALL_STATE(62)] = 2106,
  [SMALL_STATE(63)] = 2127,
  [SMALL_STATE(64)] = 2150,
  [SMALL_STATE(65)] = 2173,
  [SMALL_STATE(66)] = 2194,
  [SMALL_STATE(67)] = 2215,
  [SMALL_STATE(68)] = 2238,
  [SMALL_STATE(69)] = 2261,
  [SMALL_STATE(70)] = 2282,
  [SMALL_STATE(71)] = 2305,
  [SMALL_STATE(72)] = 2328,
  [SMALL_STATE(73)] = 2351,
  [SMALL_STATE(74)] = 2374,
  [SMALL_STATE(75)] = 2395,
  [SMALL_STATE(76)] = 2413,
  [SMALL_STATE(77)] = 2431,
  [SMALL_STATE(78)] = 2449,
  [SMALL_STATE(79)] = 2467,
  [SMALL_STATE(80)] = 2485,
  [SMALL_STATE(81)] = 2497,
  [SMALL_STATE(82)] = 2515,
  [SMALL_STATE(83)] = 2533,
  [SMALL_STATE(84)] = 2553,
  [SMALL_STATE(85)] = 2571,
  [SMALL_STATE(86)] = 2589,
  [SMALL_STATE(87)] = 2607,
  [SMALL_STATE(88)] = 2625,
  [SMALL_STATE(89)] = 2643,
  [SMALL_STATE(90)] = 2663,
  [SMALL_STATE(91)] = 2681,
  [SMALL_STATE(92)] = 2701,
  [SMALL_STATE(93)] = 2719,
  [SMALL_STATE(94)] = 2737,
  [SMALL_STATE(95)] = 2755,
  [SMALL_STATE(96)] = 2770,
  [SMALL_STATE(97)] = 2789,
  [SMALL_STATE(98)] = 2806,
  [SMALL_STATE(99)] = 2825,
  [SMALL_STATE(100)] = 2844,
  [SMALL_STATE(101)] = 2863,
  [SMALL_STATE(102)] = 2882,
  [SMALL_STATE(103)] = 2901,
  [SMALL_STATE(104)] = 2920,
  [SMALL_STATE(105)] = 2939,
  [SMALL_STATE(106)] = 2956,
  [SMALL_STATE(107)] = 2975,
  [SMALL_STATE(108)] = 2994,
  [SMALL_STATE(109)] = 3009,
  [SMALL_STATE(110)] = 3028,
  [SMALL_STATE(111)] = 3047,
  [SMALL_STATE(112)] = 3066,
  [SMALL_STATE(113)] = 3085,
  [SMALL_STATE(114)] = 3102,
  [SMALL_STATE(115)] = 3119,
  [SMALL_STATE(116)] = 3138,
  [SMALL_STATE(117)] = 3157,
  [SMALL_STATE(118)] = 3176,
  [SMALL_STATE(119)] = 3195,
  [SMALL_STATE(120)] = 3210,
  [SMALL_STATE(121)] = 3229,
  [SMALL_STATE(122)] = 3248,
  [SMALL_STATE(123)] = 3264,
  [SMALL_STATE(124)] = 3280,
  [SMALL_STATE(125)] = 3296,
  [SMALL_STATE(126)] = 3312,
  [SMALL_STATE(127)] = 3328,
  [SMALL_STATE(128)] = 3344,
  [SMALL_STATE(129)] = 3360,
  [SMALL_STATE(130)] = 3376,
  [SMALL_STATE(131)] = 3386,
  [SMALL_STATE(132)] = 3402,
  [SMALL_STATE(133)] = 3412,
  [SMALL_STATE(134)] = 3422,
  [SMALL_STATE(135)] = 3438,
  [SMALL_STATE(136)] = 3454,
  [SMALL_STATE(137)] = 3470,
  [SMALL_STATE(138)] = 3483,
  [SMALL_STATE(139)] = 3496,
  [SMALL_STATE(140)] = 3500,
  [SMALL_STATE(141)] = 3504,
};

static const TSParseActionEntry ts_parse_actions[] = {
  [0] = {.entry = {.count = 0, .reusable = false}},
  [1] = {.entry = {.count = 1, .reusable = false}}, RECOVER(),
  [3] = {.entry = {.count = 1, .reusable = false}}, SHIFT(140),
  [5] = {.entry = {.count = 1, .reusable = true}}, SHIFT(60),
  [7] = {.entry = {.count = 1, .reusable = false}}, SHIFT_EXTRA(),
  [9] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_source_file, 0, 0, 0),
  [11] = {.entry = {.count = 1, .reusable = true}}, SHIFT(5),
  [13] = {.entry = {.count = 1, .reusable = false}}, SHIFT(91),
  [15] = {.entry = {.count = 1, .reusable = false}}, SHIFT(113),
  [17] = {.entry = {.count = 1, .reusable = false}}, SHIFT(137),
  [19] = {.entry = {.count = 1, .reusable = false}}, SHIFT(80),
  [21] = {.entry = {.count = 1, .reusable = true}}, SHIFT(140),
  [23] = {.entry = {.count = 1, .reusable = true}}, SHIFT_EXTRA(),
  [25] = {.entry = {.count = 1, .reusable = true}}, SHIFT(11),
  [27] = {.entry = {.count = 1, .reusable = true}}, REDUCE(aux_sym_source_file_repeat1, 2, 0, 0),
  [29] = {.entry = {.count = 2, .reusable = true}}, REDUCE(aux_sym_source_file_repeat1, 2, 0, 0), SHIFT_REPEAT(6),
  [32] = {.entry = {.count = 2, .reusable = false}}, REDUCE(aux_sym_source_file_repeat1, 2, 0, 0), SHIFT_REPEAT(91),
  [35] = {.entry = {.count = 2, .reusable = false}}, REDUCE(aux_sym_source_file_repeat1, 2, 0, 0), SHIFT_REPEAT(113),
  [38] = {.entry = {.count = 2, .reusable = false}}, REDUCE(aux_sym_source_file_repeat1, 2, 0, 0), SHIFT_REPEAT(137),
  [41] = {.entry = {.count = 2, .reusable = false}}, REDUCE(aux_sym_source_file_repeat1, 2, 0, 0), SHIFT_REPEAT(80),
  [44] = {.entry = {.count = 2, .reusable = true}}, REDUCE(aux_sym_source_file_repeat1, 2, 0, 0), SHIFT_REPEAT(11),
  [47] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_source_file, 1, 0, 0),
  [49] = {.entry = {.count = 1, .reusable = true}}, SHIFT(4),
  [51] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_source_file, 2, 0, 0),
  [53] = {.entry = {.count = 1, .reusable = true}}, SHIFT(14),
  [55] = {.entry = {.count = 1, .reusable = true}}, REDUCE(aux_sym_directive_repeat1, 1, 0, 0),
  [57] = {.entry = {.count = 1, .reusable = false}}, SHIFT(28),
  [59] = {.entry = {.count = 1, .reusable = true}}, SHIFT(123),
  [61] = {.entry = {.count = 1, .reusable = true}}, SHIFT(19),
  [63] = {.entry = {.count = 1, .reusable = true}}, SHIFT(99),
  [65] = {.entry = {.count = 1, .reusable = true}}, SHIFT(78),
  [67] = {.entry = {.count = 1, .reusable = false}}, SHIFT(20),
  [69] = {.entry = {.count = 1, .reusable = true}}, SHIFT(38),
  [71] = {.entry = {.count = 1, .reusable = false}}, SHIFT(30),
  [73] = {.entry = {.count = 1, .reusable = true}}, REDUCE(aux_sym_assignment_repeat1, 1, 0, 0),
  [75] = {.entry = {.count = 1, .reusable = true}}, SHIFT(10),
  [77] = {.entry = {.count = 1, .reusable = true}}, SHIFT(101),
  [79] = {.entry = {.count = 1, .reusable = true}}, SHIFT(22),
  [81] = {.entry = {.count = 1, .reusable = true}}, SHIFT(17),
  [83] = {.entry = {.count = 1, .reusable = true}}, SHIFT(94),
  [85] = {.entry = {.count = 1, .reusable = true}}, SHIFT(62),
  [87] = {.entry = {.count = 1, .reusable = true}}, SHIFT(15),
  [89] = {.entry = {.count = 1, .reusable = true}}, REDUCE(aux_sym_source_file_repeat1, 1, 0, 0),
  [91] = {.entry = {.count = 1, .reusable = false}}, REDUCE(aux_sym_source_file_repeat1, 1, 0, 0),
  [93] = {.entry = {.count = 1, .reusable = true}}, REDUCE(aux_sym_source_file_repeat1, 3, 0, 0),
  [95] = {.entry = {.count = 1, .reusable = false}}, REDUCE(aux_sym_source_file_repeat1, 3, 0, 0),
  [97] = {.entry = {.count = 1, .reusable = false}}, REDUCE(aux_sym_source_file_repeat1, 2, 0, 0),
  [99] = {.entry = {.count = 1, .reusable = true}}, SHIFT(75),
  [101] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_number, 1, 0, 0),
  [103] = {.entry = {.count = 1, .reusable = false}}, REDUCE(sym_number, 1, 0, 0),
  [105] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym__operand_symbol, 1, 0, 0),
  [107] = {.entry = {.count = 1, .reusable = false}}, REDUCE(sym__operand_symbol, 1, 0, 0),
  [109] = {.entry = {.count = 1, .reusable = true}}, SHIFT(35),
  [111] = {.entry = {.count = 1, .reusable = true}}, SHIFT(116),
  [113] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_expression, 3, 0, 0),
  [115] = {.entry = {.count = 1, .reusable = false}}, REDUCE(sym_expression, 3, 0, 0),
  [117] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym__paren_expression, 3, 0, 0),
  [119] = {.entry = {.count = 1, .reusable = false}}, REDUCE(sym__paren_expression, 3, 0, 0),
  [121] = {.entry = {.count = 1, .reusable = true}}, SHIFT(115),
  [123] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym__sub_expression, 1, 0, 0),
  [125] = {.entry = {.count = 1, .reusable = false}}, REDUCE(sym__sub_expression, 1, 0, 0),
  [127] = {.entry = {.count = 1, .reusable = true}}, SHIFT(121),
  [129] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym__operand_expression, 1, 0, 0),
  [131] = {.entry = {.count = 1, .reusable = false}}, REDUCE(sym__operand_expression, 1, 0, 0),
  [133] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym__displacement_expression_offset, 1, 0, 0),
  [135] = {.entry = {.count = 1, .reusable = true}}, SHIFT(51),
  [137] = {.entry = {.count = 1, .reusable = false}}, SHIFT(51),
  [139] = {.entry = {.count = 1, .reusable = true}}, SHIFT(98),
  [141] = {.entry = {.count = 1, .reusable = true}}, SHIFT(107),
  [143] = {.entry = {.count = 1, .reusable = true}}, SHIFT(100),
  [145] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym__operand_symbol, 2, 0, 0),
  [147] = {.entry = {.count = 1, .reusable = false}}, REDUCE(sym__operand_symbol, 2, 0, 0),
  [149] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_expression, 1, 0, 0),
  [151] = {.entry = {.count = 1, .reusable = false}}, REDUCE(sym_expression, 1, 0, 0),
  [153] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym__operand_expression, 3, 0, 0),
  [155] = {.entry = {.count = 1, .reusable = false}}, REDUCE(sym__operand_expression, 3, 0, 0),
  [157] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_symbol, 1, 0, 0),
  [159] = {.entry = {.count = 1, .reusable = false}}, REDUCE(sym_symbol, 1, 0, 0),
  [161] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym__operand, 1, 0, 0),
  [163] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_directive, 3, 0, 0),
  [165] = {.entry = {.count = 1, .reusable = true}}, SHIFT(119),
  [167] = {.entry = {.count = 1, .reusable = false}}, SHIFT(95),
  [169] = {.entry = {.count = 1, .reusable = true}}, SHIFT(108),
  [171] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym__directive_arg, 1, 0, 0),
  [173] = {.entry = {.count = 1, .reusable = true}}, SHIFT(21),
  [175] = {.entry = {.count = 1, .reusable = false}}, SHIFT(21),
  [177] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_constant, 2, 0, 0),
  [179] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_directive, 2, 0, 0),
  [181] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_assignment, 4, 0, 0),
  [183] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_assignment, 3, 0, 0),
  [185] = {.entry = {.count = 1, .reusable = true}}, SHIFT(26),
  [187] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_instruction, 6, 0, 2),
  [189] = {.entry = {.count = 1, .reusable = true}}, SHIFT(13),
  [191] = {.entry = {.count = 1, .reusable = false}}, SHIFT(83),
  [193] = {.entry = {.count = 1, .reusable = true}}, SHIFT(139),
  [195] = {.entry = {.count = 1, .reusable = true}}, SHIFT(133),
  [197] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym__displacement_expression, 3, 0, 0),
  [199] = {.entry = {.count = 1, .reusable = true}}, SHIFT(111),
  [201] = {.entry = {.count = 1, .reusable = true}}, SHIFT(7),
  [203] = {.entry = {.count = 1, .reusable = true}}, SHIFT(132),
  [205] = {.entry = {.count = 1, .reusable = true}}, SHIFT(141),
  [207] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_instruction, 5, 0, 1),
  [209] = {.entry = {.count = 1, .reusable = true}}, SHIFT(32),
  [211] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_instruction, 3, 0, 1),
  [213] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_instruction, 5, 0, 2),
  [215] = {.entry = {.count = 1, .reusable = true}}, REDUCE(aux_sym_instruction_repeat1, 2, 0, 0),
  [217] = {.entry = {.count = 2, .reusable = true}}, REDUCE(aux_sym_instruction_repeat1, 2, 0, 0), SHIFT_REPEAT(13),
  [220] = {.entry = {.count = 1, .reusable = true}}, REDUCE(aux_sym_directive_repeat1, 2, 0, 0),
  [222] = {.entry = {.count = 2, .reusable = true}}, REDUCE(aux_sym_directive_repeat1, 2, 0, 0), SHIFT_REPEAT(7),
  [225] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_instruction, 1, 0, 1),
  [227] = {.entry = {.count = 1, .reusable = true}}, SHIFT(23),
  [229] = {.entry = {.count = 1, .reusable = true}}, SHIFT(130),
  [231] = {.entry = {.count = 1, .reusable = true}}, SHIFT(59),
  [233] = {.entry = {.count = 1, .reusable = true}}, SHIFT(8),
  [235] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_char, 2, 0, 0),
  [237] = {.entry = {.count = 1, .reusable = true}}, SHIFT(85),
  [239] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_directive, 4, 0, 0),
  [241] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_instruction, 4, 0, 1),
  [243] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_instruction, 7, 0, 2),
  [245] = {.entry = {.count = 2, .reusable = false}}, REDUCE(aux_sym_comment_repeat1, 2, 0, 0), SHIFT_REPEAT(83),
  [248] = {.entry = {.count = 1, .reusable = true}}, REDUCE(aux_sym_comment_repeat1, 2, 0, 0),
  [250] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym__displacement_expression, 6, 0, 0),
  [252] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym__displacement_expression, 5, 0, 0),
  [254] = {.entry = {.count = 1, .reusable = true}}, REDUCE(aux_sym_directive_repeat2, 2, 0, 0),
  [256] = {.entry = {.count = 2, .reusable = true}}, REDUCE(aux_sym_directive_repeat2, 2, 0, 0), SHIFT_REPEAT(52),
  [259] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym__displacement_expression, 4, 0, 0),
  [261] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym__displacement_expression, 7, 0, 0),
  [263] = {.entry = {.count = 1, .reusable = false}}, REDUCE(aux_sym_comment_repeat1, 1, 0, 0),
  [265] = {.entry = {.count = 1, .reusable = true}}, REDUCE(aux_sym_comment_repeat1, 1, 0, 0),
  [267] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_type, 2, 0, 0),
  [269] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_char, 3, 0, 0),
  [271] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym__displacement_expression, 8, 0, 0),
  [273] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym__displacement_expression, 9, 0, 0),
  [275] = {.entry = {.count = 1, .reusable = true}}, SHIFT(42),
  [277] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym__displacement_expression, 10, 0, 0),
  [279] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_directive, 1, 0, 0),
  [281] = {.entry = {.count = 1, .reusable = true}}, SHIFT(47),
  [283] = {.entry = {.count = 1, .reusable = true}}, SHIFT(27),
  [285] = {.entry = {.count = 1, .reusable = true}}, SHIFT(76),
  [287] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_instruction, 3, 0, 2),
  [289] = {.entry = {.count = 1, .reusable = true}}, SHIFT(9),
  [291] = {.entry = {.count = 1, .reusable = true}}, SHIFT(24),
  [293] = {.entry = {.count = 1, .reusable = true}}, SHIFT(110),
  [295] = {.entry = {.count = 1, .reusable = false}}, SHIFT(69),
  [297] = {.entry = {.count = 1, .reusable = true}}, SHIFT(69),
  [299] = {.entry = {.count = 1, .reusable = true}}, SHIFT(41),
  [301] = {.entry = {.count = 1, .reusable = true}}, SHIFT(81),
  [303] = {.entry = {.count = 1, .reusable = true}}, SHIFT(34),
  [305] = {.entry = {.count = 1, .reusable = true}}, SHIFT(120),
  [307] = {.entry = {.count = 1, .reusable = true}}, SHIFT(18),
  [309] = {.entry = {.count = 1, .reusable = true}}, SHIFT(105),
  [311] = {.entry = {.count = 1, .reusable = true}}, REDUCE(aux_sym_assignment_repeat1, 2, 0, 0),
  [313] = {.entry = {.count = 2, .reusable = true}}, REDUCE(aux_sym_assignment_repeat1, 2, 0, 0), SHIFT_REPEAT(130),
  [316] = {.entry = {.count = 2, .reusable = true}}, REDUCE(aux_sym_assignment_repeat1, 2, 0, 0), SHIFT_REPEAT(59),
  [319] = {.entry = {.count = 2, .reusable = true}}, REDUCE(aux_sym_assignment_repeat1, 2, 0, 0), SHIFT_REPEAT(105),
  [322] = {.entry = {.count = 1, .reusable = true}}, SHIFT(39),
  [324] = {.entry = {.count = 1, .reusable = true}}, SHIFT(77),
  [326] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_source_file, 3, 0, 0),
  [328] = {.entry = {.count = 1, .reusable = true}}, SHIFT(12),
  [330] = {.entry = {.count = 1, .reusable = true}}, SHIFT(29),
  [332] = {.entry = {.count = 1, .reusable = true}}, SHIFT(96),
  [334] = {.entry = {.count = 1, .reusable = true}}, SHIFT(33),
  [336] = {.entry = {.count = 1, .reusable = true}}, SHIFT(102),
  [338] = {.entry = {.count = 1, .reusable = true}}, SHIFT(16),
  [340] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym__statement, 1, 0, 0),
  [342] = {.entry = {.count = 1, .reusable = true}}, SHIFT(44),
  [344] = {.entry = {.count = 1, .reusable = true}}, SHIFT(87),
  [346] = {.entry = {.count = 1, .reusable = true}}, SHIFT(48),
  [348] = {.entry = {.count = 1, .reusable = true}}, SHIFT(93),
  [350] = {.entry = {.count = 1, .reusable = true}}, SHIFT(45),
  [352] = {.entry = {.count = 1, .reusable = true}}, SHIFT(82),
  [354] = {.entry = {.count = 1, .reusable = true}},  ACCEPT_INPUT(),
  [356] = {.entry = {.count = 1, .reusable = true}}, SHIFT(84),
  [358] = {.entry = {.count = 1, .reusable = true}}, SHIFT(88),
  [360] = {.entry = {.count = 1, .reusable = true}}, SHIFT(90),
  [362] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_comment, 1, 0, 0),
  [364] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_comment, 2, 0, 0),
  [366] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_comment, 3, 0, 0),
  [368] = {.entry = {.count = 1, .reusable = true}}, SHIFT(112),
  [370] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_instruction_prefix, 1, 0, 0),
  [372] = {.entry = {.count = 1, .reusable = true}}, SHIFT(103),
};

#ifdef __cplusplus
extern "C" {
#endif
#ifdef TREE_SITTER_HIDE_SYMBOLS
#define TS_PUBLIC
#elif defined(_WIN32)
#define TS_PUBLIC __declspec(dllexport)
#else
#define TS_PUBLIC __attribute__((visibility("default")))
#endif

TS_PUBLIC const TSLanguage *tree_sitter_gas(void) {
  static const TSLanguage language = {
    .version = LANGUAGE_VERSION,
    .symbol_count = SYMBOL_COUNT,
    .alias_count = ALIAS_COUNT,
    .token_count = TOKEN_COUNT,
    .external_token_count = EXTERNAL_TOKEN_COUNT,
    .state_count = STATE_COUNT,
    .large_state_count = LARGE_STATE_COUNT,
    .production_id_count = PRODUCTION_ID_COUNT,
    .field_count = FIELD_COUNT,
    .max_alias_sequence_length = MAX_ALIAS_SEQUENCE_LENGTH,
    .parse_table = &ts_parse_table[0][0],
    .small_parse_table = ts_small_parse_table,
    .small_parse_table_map = ts_small_parse_table_map,
    .parse_actions = ts_parse_actions,
    .symbol_names = ts_symbol_names,
    .symbol_metadata = ts_symbol_metadata,
    .public_symbol_map = ts_symbol_map,
    .alias_map = ts_non_terminal_alias_map,
    .alias_sequences = &ts_alias_sequences[0][0],
    .lex_modes = ts_lex_modes,
    .lex_fn = ts_lex,
    .primary_state_ids = ts_primary_state_ids,
  };
  return &language;
}
#ifdef __cplusplus
}
#endif
